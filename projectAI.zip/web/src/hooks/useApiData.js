import { useState, useEffect } from "react";

export function useApiData(activeTab) {
  const [vehicles, setVehicles] = useState([]);
  const [stations, setStations] = useState([]);
  const [analytics, setAnalytics] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchData = async () => {
      setLoading(true);
      setError(null);

      try {
        if (activeTab === "driver") {
          // Fetch vehicles and charging stations for driver tab
          const [vehiclesResponse, stationsResponse] = await Promise.all([
            fetch("/api/vehicles"),
            fetch("/api/charging-stations"),
          ]);

          if (!vehiclesResponse.ok) {
            throw new Error(
              `Failed to fetch vehicles: ${vehiclesResponse.status}`,
            );
          }
          if (!stationsResponse.ok) {
            throw new Error(
              `Failed to fetch stations: ${stationsResponse.status}`,
            );
          }

          const vehiclesData = await vehiclesResponse.json();
          const stationsData = await stationsResponse.json();

          // Extract the vehicles array from the response object
          setVehicles(vehiclesData.vehicles || []);
          setStations(stationsData.stations || []);
        } else if (activeTab === "business") {
          // Fetch analytics for business tab
          const analyticsResponse = await fetch("/api/business-analytics");

          if (!analyticsResponse.ok) {
            throw new Error(
              `Failed to fetch analytics: ${analyticsResponse.status}`,
            );
          }

          const analyticsData = await analyticsResponse.json();
          setAnalytics(analyticsData);
        }
      } catch (err) {
        console.error("Error fetching data:", err);
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [activeTab]);

  return {
    vehicles,
    stations,
    analytics,
    loading,
    error,
  };
}
