import { useState, useEffect } from "react";

export function useTeslaData() {
  const [selectedVehicle, setSelectedVehicle] = useState(null);
  const [vehicles, setVehicles] = useState([]);
  const [stations, setStations] = useState([]);
  const [destination, setDestination] = useState("");
  const [destinationCoords, setDestinationCoords] = useState(null);
  const [batteryLevel, setBatteryLevel] = useState(85);
  const [currentRoute, setCurrentRoute] = useState(null);
  const [batteryThreshold, setBatteryThreshold] = useState(20);
  const [mapCenter, setMapCenter] = useState({ lat: 37.7749, lng: -122.4194 });
  const [currentLocation, setCurrentLocation] = useState({
    lat: 37.7749,
    lng: -122.4194,
  });
  const [loading, setLoading] = useState(true);
  const [routeLoading, setRouteLoading] = useState(false);
  const [routeError, setRouteError] = useState(null);
  
  // Load vehicles and stations from API
  useEffect(() => {
    const loadData = async () => {
      try {
        setLoading(true);
        const [vehiclesResponse, stationsResponse] = await Promise.all([
          fetch("/api/vehicles"),
          fetch("/api/charging-stations"),
        ]);

        if (vehiclesResponse.ok) {
          const vehiclesData = await vehiclesResponse.json();
          setVehicles(vehiclesData.vehicles || []);
          if (vehiclesData.vehicles?.length > 0) {
            setSelectedVehicle(vehiclesData.vehicles[0]);
          }
        } else {
          console.error("Failed to load vehicles");
        }

        if (stationsResponse.ok) {
          const stationsData = await stationsResponse.json();
          setStations(stationsData.stations || []);
        } else {
          console.error("Failed to load charging stations");
        }
      } catch (error) {
        console.error("Error loading data:", error);
      } finally {
        setLoading(false);
      }
    };
    loadData();
  }, []);

  // Get current location
  useEffect(() => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          const coords = {
            lat: position.coords.latitude,
            lng: position.coords.longitude,
          };
          setMapCenter(coords);
          setCurrentLocation(coords);
        },
        (error) => {
          console.log("Geolocation error:", error);
        }
      );
    }
  }, []);
  
  const calculateRoute = async () => {
    if (!destinationCoords || !selectedVehicle || !currentLocation) return;
    try {
      setRouteLoading(true);
      setRouteError(null);
      const response = await fetch("/api/route-optimization", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          startLat: currentLocation.lat,
          startLng: currentLocation.lng,
          endLat: destinationCoords.lat,
          endLng: destinationCoords.lng,
          vehicleModelId: selectedVehicle.id,
          batteryPercent: batteryLevel,
          minBatteryThreshold: batteryThreshold,
        }),
      });
      if (!response.ok) throw new Error(`Route calculation failed: ${response.status}`);
      const data = await response.json();
      setCurrentRoute(data.route);
    } catch (error) {
      console.error("Error calculating route:", error);
      setRouteError("Failed to calculate route. Please try again.");
    } finally {
      setRouteLoading(false);
    }
  };

  // Recalculate route when destination, vehicle, or battery settings change
  useEffect(() => {
    if (destinationCoords && selectedVehicle && currentLocation) {
      calculateRoute();
    }
  }, [destinationCoords, selectedVehicle, batteryLevel, batteryThreshold, currentLocation]);

  const handleDestinationChange = (value) => {
    setDestination(value);
    if (!value.trim()) {
      setDestinationCoords(null);
      setCurrentRoute(null);
      return;
    }
    // Simple geocoding for demo
    if (value.toLowerCase().includes("los angeles") || value.toLowerCase().includes("la")) {
      setDestinationCoords({ lat: 34.0522, lng: -118.2437 });
    } else if (value.toLowerCase().includes("san francisco") || value.toLowerCase().includes("sf")) {
      setDestinationCoords({ lat: 37.7749, lng: -122.4194 });
    } else if (value.toLowerCase().includes("sacramento")) {
      setDestinationCoords({ lat: 38.5816, lng: -121.4944 });
    } else if (value.toLowerCase().includes("san jose")) {
      setDestinationCoords({ lat: 37.3382, lng: -121.8863 });
    }
  };
  
  const handleMapClick = (event) => {
    const lat = event.detail.latLng.lat;
    const lng = event.detail.latLng.lng;
    setDestinationCoords({ lat, lng });

    if (window.google && window.google.maps) {
      const geocoder = new window.google.maps.Geocoder();
      geocoder.geocode({ location: { lat, lng } }, (results, status) => {
        if (status === "OK" && results[0]) {
          setDestination(results[0].formatted_address);
        } else {
          setDestination(`${lat.toFixed(4)}, ${lng.toFixed(4)}`);
        }
      });
    } else {
      setDestination(`${lat.toFixed(4)}, ${lng.toFixed(4)}`);
    }
  };

  const startNavigation = () => {
    if (destinationCoords) {
      alert(`Navigation started to ${destination}`);
      setCurrentRoute((prev) => (prev ? { ...prev, navigationStarted: true } : null));
    }
  };

  return {
    selectedVehicle, setSelectedVehicle,
    vehicles,
    stations,
    destination,
    destinationCoords,
    batteryLevel, setBatteryLevel,
    currentRoute,
    batteryThreshold, setBatteryThreshold,
    mapCenter,
    currentLocation,
    loading,
    routeLoading,
    routeError,
    calculateRoute,
    handleDestinationChange,
    handleMapClick,
    startNavigation
  };
}
