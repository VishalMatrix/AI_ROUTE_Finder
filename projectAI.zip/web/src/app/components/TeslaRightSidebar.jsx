import React from "react";
import { motion } from "motion/react";
import { Navigation, Loader, Battery } from "lucide-react";
import { Vehicle3DCard } from "./Vehicle3DCard";

export function TeslaRightSidebar({
  destination,
  handleDestinationChange,
  vehicles,
  selectedVehicle,
  setSelectedVehicle,
  loading,
  startNavigation,
  calculateRoute,
  destinationCoords,
  routeLoading,
}) {
  return (
    <div className="w-80 bg-gray-900 p-4">
      {/* Destination Input */}
      <div className="mb-6">
        <label className="text-xs text-gray-400 block mb-2">Destination</label>
        <input
          type="text"
          value={destination}
          onChange={(e) => handleDestinationChange(e.target.value)}
          placeholder="Where to? (try: Los Angeles, San Jose, Sacramento)"
          className="w-full bg-gray-800 text-white rounded-lg px-4 py-3 border border-gray-700 focus:border-blue-500 focus:outline-none transition-colors text-sm"
        />
      </div>

      {/* 3D Vehicle Selection */}
      <div className="mb-6">
        <h3 className="text-sm font-semibold mb-3">Select Vehicle</h3>
        <div className="space-y-3 max-h-48 overflow-y-auto">
          {vehicles?.map((vehicle) => (
            <Vehicle3DCard
              key={vehicle.id}
              vehicle={vehicle}
              isSelected={selectedVehicle?.id === vehicle.id}
              onClick={() => setSelectedVehicle(vehicle)}
            />
          ))}
        </div>
        {vehicles?.length === 0 && !loading && (
          <div className="text-xs text-gray-400 text-center py-4">
            No vehicles available. Check your database connection.
          </div>
        )}
      </div>

      {/* Selected Vehicle Details */}
      {selectedVehicle && (
        <motion.div
          className="mb-6 bg-gray-800 rounded-lg p-4"
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.3 }}
        >
          <h3 className="text-sm font-semibold mb-3">
            {selectedVehicle.make} {selectedVehicle.model}
          </h3>
          <div className="grid grid-cols-2 gap-3 text-xs">
            <div className="bg-gray-900 rounded p-2">
              <span className="text-gray-400">Battery:</span>
              <div className="text-white font-medium">
                {selectedVehicle.battery_capacity_kwh} kWh
              </div>
            </div>
            <div className="bg-gray-900 rounded p-2">
              <span className="text-gray-400">Range:</span>
              <div className="text-white font-medium">
                {selectedVehicle.range_miles} mi
              </div>
            </div>
            <div className="bg-gray-900 rounded p-2">
              <span className="text-gray-400">Efficiency:</span>
              <div className="text-white font-medium">
                {selectedVehicle.efficiency_kwh_per_mile} kWh/mi
              </div>
            </div>
            <div className="bg-gray-900 rounded p-2">
              <span className="text-gray-400">Max Charging:</span>
              <div className="text-white font-medium">
                {selectedVehicle.charging_speed_kw} kW
              </div>
            </div>
          </div>
        </motion.div>
      )}

      {/* Quick Actions */}
      <div className="space-y-3">
        <motion.button
          onClick={startNavigation}
          disabled={!destinationCoords || routeLoading}
          className={`w-full py-3 rounded-lg font-semibold transition-colors flex items-center justify-center space-x-2 ${
            destinationCoords && !routeLoading
              ? "bg-green-600 hover:bg-green-700 text-white"
              : "bg-gray-700 text-gray-400 cursor-not-allowed"
          }`}
          whileHover={
            destinationCoords && !routeLoading ? { scale: 1.05 } : {}
          }
          whileTap={destinationCoords && !routeLoading ? { scale: 0.95 } : {}}
        >
          {routeLoading ? (
            <>
              <Loader className="w-4 h-4 animate-spin" />
              <span>Calculating Route...</span>
            </>
          ) : (
            <>
              <Navigation className="w-4 h-4" />
              <span>Start Navigation</span>
            </>
          )}
        </motion.button>

        <motion.button
          onClick={calculateRoute}
          disabled={!destinationCoords || !selectedVehicle || routeLoading}
          className={`w-full py-3 rounded-lg font-semibold transition-colors flex items-center justify-center space-x-2 ${
            destinationCoords && selectedVehicle && !routeLoading
              ? "bg-blue-600 hover:bg-blue-700 text-white"
              : "bg-gray-700 text-gray-400 cursor-not-allowed"
          }`}
          whileHover={
            destinationCoords && selectedVehicle && !routeLoading
              ? { scale: 1.05 }
              : {}
          }
          whileTap={
            destinationCoords && selectedVehicle && !routeLoading
              ? { scale: 0.95 }
              : {}
          }
        >
          <Battery className="w-4 h-4" />
          <span>Recalculate Route</span>
        </motion.button>
      </div>
    </div>
  );
}
