import React from "react";
import { motion } from "motion/react";
import { Settings, AlertTriangle, Zap, Battery } from "lucide-react";

export function TeslaLeftSidebar({
  batteryLevel,
  setBatteryLevel,
  batteryThreshold,
  setBatteryThreshold,
  stations,
  selectedVehicle,
}) {
  return (
    <div className="w-64 bg-gray-900 p-4">
      {/* Battery Threshold Settings */}
      <div className="mb-6 bg-gray-800 rounded-lg p-4">
        <h3 className="text-sm font-semibold mb-3 flex items-center">
          <Settings className="w-4 h-4 mr-2" />
          Battery Settings
        </h3>
        <div className="space-y-4">
          <div>
            <label className="text-xs text-gray-400 block mb-2">
              Current Battery Level
            </label>
            <div className="flex items-center space-x-3">
              <input
                type="range"
                min="10"
                max="100"
                value={batteryLevel}
                onChange={(e) => setBatteryLevel(parseInt(e.target.value))}
                className="flex-1 h-2 bg-gray-700 rounded-lg appearance-none cursor-pointer"
              />
              <span className="text-sm font-medium w-12">{batteryLevel}%</span>
            </div>
          </div>
          <div>
            <label className="text-xs text-gray-400 block mb-2">
              Minimum Battery at Arrival
            </label>
            <div className="flex items-center space-x-3">
              <input
                type="range"
                min="10"
                max="50"
                value={batteryThreshold}
                onChange={(e) => setBatteryThreshold(parseInt(e.target.value))}
                className="flex-1 h-2 bg-gray-700 rounded-lg appearance-none cursor-pointer slider"
              />
              <span className="text-sm font-medium w-12">
                {batteryThreshold}%
              </span>
            </div>
            <div className="flex items-center mt-2 text-xs">
              <AlertTriangle className="w-3 h-3 mr-1 text-yellow-400" />
              <span className="text-gray-400">
                Routes will show warnings below this threshold
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Charging Stations Quick Access */}
      <div className="bg-gray-800 rounded-lg p-4">
        <h3 className="text-sm font-semibold mb-3 flex items-center">
          <Zap className="w-4 h-4 mr-2 text-blue-400" />
          Charging Network
        </h3>
        <div className="space-y-2">
          <motion.button
            className="w-full bg-blue-600 rounded-lg p-3 flex items-center justify-center space-x-2 hover:bg-blue-700 transition-colors"
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            <Zap className="w-4 h-4" />
            <span className="text-sm font-medium">Find Stations</span>
          </motion.button>
          <div className="text-xs text-gray-400 text-center">
            {stations?.length || 0} stations nearby
          </div>
        </div>
      </div>

      {/* Vehicle Status */}
      <div className="mt-6 bg-gray-800 rounded-lg p-4">
        <h3 className="text-sm font-semibold mb-3">Current Status</h3>
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs text-gray-400">Battery</span>
            <div className="flex items-center space-x-2">
              <Battery
                className={`w-4 h-4 ${
                  batteryLevel > batteryThreshold
                    ? "text-green-400"
                    : "text-yellow-400"
                }`}
              />
              <span className="text-sm">{batteryLevel}%</span>
            </div>
          </div>
          <div className="flex items-center justify-between">
            <span className="text-xs text-gray-400">Estimated Range</span>
            <span className="text-sm">
              {selectedVehicle
                ? Math.round((batteryLevel / 100) * selectedVehicle.range_miles)
                : Math.round(batteryLevel * 4)}{" "}
              mi
            </span>
          </div>
          <div className="flex items-center justify-between">
            <span className="text-xs text-gray-400">Temperature</span>
            <span className="text-sm">72°F</span>
          </div>
          {batteryLevel <= batteryThreshold && (
            <motion.div
              className="bg-yellow-900 border border-yellow-600 rounded-lg p-2 mt-3"
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.3 }}
            >
              <div className="flex items-center text-yellow-400 text-xs">
                <AlertTriangle className="w-3 h-3 mr-1" />
                Low battery - find charging station
              </div>
            </motion.div>
          )}
        </div>
      </div>
    </div>
  );
}

export default TeslaLeftSidebar;
