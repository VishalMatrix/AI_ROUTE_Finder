import React, { useState, useCallback } from 'react';
import { APIProvider, Map, Marker, InfoWindow } from '@vis.gl/react-google-maps';
import { MapPin, Zap, Clock, DollarSign } from 'lucide-react';

const EVRouteMap = ({ 
  routeResult, 
  chargingStations = [], 
  startLocation, 
  endLocation,
  className = "" 
}) => {
  const [selectedStation, setSelectedStation] = useState(null);
  const [mapCenter, setMapCenter] = useState({
    lat: startLocation?.lat || 37.7749,
    lng: startLocation?.lng || -122.4194
  });

  const API_KEY = process.env.NEXT_PUBLIC_GOOGLE_MAPS_API_KEY;

  const handleMarkerClick = useCallback((station) => {
    setSelectedStation(station);
  }, []);

  const handleInfoWindowClose = useCallback(() => {
    setSelectedStation(null);
  }, []);

  // Get marker color based on charging speed
  const getMarkerColor = (chargingSpeedKw) => {
    if (chargingSpeedKw >= 150) return '#10B981'; // Green for fast charging
    if (chargingSpeedKw >= 50) return '#F59E0B';  // Yellow for medium
    return '#EF4444'; // Red for slow charging
  };

  // Get availability status color
  const getAvailabilityColor = (available, total) => {
    const ratio = available / total;
    if (ratio > 0.7) return 'text-green-600';
    if (ratio > 0.3) return 'text-yellow-600';
    return 'text-red-600';
  };

  return (
    <div className={`relative ${className}`}>
      {API_KEY ? (
        <APIProvider apiKey={API_KEY}>
          <Map
            style={{ width: '100%', height: '100%' }}
            defaultCenter={mapCenter}
            defaultZoom={11}
            gestureHandling="greedy"
            disableDefaultUI={false}
            mapTypeControl={false}
            streetViewControl={false}
            fullscreenControl={false}
          >
            {/* Start Location Marker */}
            {startLocation && (
              <Marker
                position={{ lat: startLocation.lat, lng: startLocation.lng }}
                title="Start Location"
              />
            )}

            {/* End Location Marker */}
            {endLocation && (
              <Marker
                position={{ lat: endLocation.lat, lng: endLocation.lng }}
                title="Destination"
              />
            )}

            {/* Charging Station Markers */}
            {chargingStations.map((station) => (
              <Marker
                key={station.id}
                position={{ lat: parseFloat(station.latitude), lng: parseFloat(station.longitude) }}
                onClick={() => handleMarkerClick(station)}
                title={station.name}
                icon={{
                  path: 'M12 2L13.09 8.26L22 9L13.09 9.74L12 16L10.91 9.74L2 9L10.91 8.26L12 2Z',
                  fillColor: getMarkerColor(station.charging_speed_kw),
                  fillOpacity: 1,
                  strokeColor: '#ffffff',
                  strokeWeight: 2,
                  scale: 1.5,
                }}
              />
            ))}

            {/* Route Charging Stops (if route is calculated) */}
            {routeResult?.chargingStops?.map((stop, index) => (
              <Marker
                key={`route-stop-${index}`}
                position={{ 
                  lat: parseFloat(stop.station.latitude), 
                  lng: parseFloat(stop.station.longitude) 
                }}
                onClick={() => handleMarkerClick(stop.station)}
                title={`Recommended Stop: ${stop.station.name}`}
                icon={{
                  path: 'M12 2L13.09 8.26L22 9L13.09 9.74L12 16L10.91 9.74L2 9L10.91 8.26L12 2Z',
                  fillColor: '#3B82F6',
                  fillOpacity: 1,
                  strokeColor: '#ffffff',
                  strokeWeight: 3,
                  scale: 2,
                }}
              />
            ))}

            {/* Info Window for Selected Station */}
            {selectedStation && (
              <InfoWindow
                position={{ 
                  lat: parseFloat(selectedStation.latitude), 
                  lng: parseFloat(selectedStation.longitude) 
                }}
                onCloseClick={handleInfoWindowClose}
              >
                <div className="p-3 min-w-[280px]">
                  <div className="flex items-start justify-between mb-2">
                    <h3 className="font-semibold text-gray-900 text-sm">
                      {selectedStation.name}
                    </h3>
                    <div className="flex items-center">
                      <Zap className="h-4 w-4 text-yellow-500 mr-1" />
                      <span className="text-sm font-medium">
                        {selectedStation.charging_speed_kw}kW
                      </span>
                    </div>
                  </div>
                  
                  <p className="text-xs text-gray-600 mb-3">
                    {selectedStation.address}
                  </p>
                  
                  <div className="grid grid-cols-2 gap-2 text-xs">
                    <div className="flex items-center">
                      <MapPin className="h-3 w-3 text-gray-400 mr-1" />
                      <span>{selectedStation.provider}</span>
                    </div>
                    
                    <div className="flex items-center">
                      <span className={`font-medium ${getAvailabilityColor(
                        selectedStation.available_ports, 
                        selectedStation.total_ports
                      )}`}>
                        {selectedStation.available_ports}/{selectedStation.total_ports} available
                      </span>
                    </div>
                    
                    {selectedStation.cost_per_kwh && (
                      <div className="flex items-center">
                        <DollarSign className="h-3 w-3 text-gray-400 mr-1" />
                        <span>${selectedStation.cost_per_kwh}/kWh</span>
                      </div>
                    )}
                    
                    <div className="flex items-center">
                      <Clock className="h-3 w-3 text-gray-400 mr-1" />
                      <span className="text-green-600">Available now</span>
                    </div>
                  </div>

                  {/* If this is a route stop, show additional info */}
                  {routeResult?.chargingStops?.find(stop => 
                    stop.station.id === selectedStation.id
                  ) && (
                    <div className="mt-3 pt-2 border-t border-gray-200">
                      {(() => {
                        const routeStop = routeResult.chargingStops.find(stop => 
                          stop.station.id === selectedStation.id
                        );
                        return (
                          <div className="text-xs space-y-1">
                            <div className="flex justify-between">
                              <span className="text-gray-600">Charging Time:</span>
                              <span className="font-medium text-blue-600">
                                {routeStop.chargingTimeMinutes} min
                              </span>
                            </div>
                            <div className="flex justify-between">
                              <span className="text-gray-600">Estimated Cost:</span>
                              <span className="font-medium text-green-600">
                                ${routeStop.cost?.toFixed(2) || 'N/A'}
                              </span>
                            </div>
                          </div>
                        );
                      })()}
                    </div>
                  )}
                </div>
              </InfoWindow>
            )}
          </Map>
        </APIProvider>
      ) : (
        <div className="flex items-center justify-center h-full bg-gray-100 rounded-lg">
          <div className="text-center">
            <MapPin className="h-12 w-12 text-gray-400 mx-auto mb-3" />
            <p className="text-gray-600">Google Maps API key required</p>
            <p className="text-sm text-gray-500">
              Add NEXT_PUBLIC_GOOGLE_MAPS_API_KEY to environment variables
            </p>
          </div>
        </div>
      )}
      
      {/* Map Legend */}
      <div className="absolute top-4 left-4 bg-white rounded-lg shadow-lg p-3 text-xs">
        <h4 className="font-semibold mb-2">Charging Speeds</h4>
        <div className="space-y-1">
          <div className="flex items-center">
            <div className="w-3 h-3 rounded-full bg-green-500 mr-2"></div>
            <span>Fast (150+ kW)</span>
          </div>
          <div className="flex items-center">
            <div className="w-3 h-3 rounded-full bg-yellow-500 mr-2"></div>
            <span>Medium (50-149 kW)</span>
          </div>
          <div className="flex items-center">
            <div className="w-3 h-3 rounded-full bg-red-500 mr-2"></div>
            <span>Slow (&lt;50 kW)</span>
          </div>
          <div className="flex items-center mt-2 pt-2 border-t">
            <div className="w-3 h-3 rounded-full bg-blue-500 mr-2"></div>
            <span>Recommended Stop</span>
          </div>
        </div>
      </div>

      {/* Real-time Status Indicator */}
      <div className="absolute top-4 right-4 bg-white rounded-lg shadow-lg p-2">
        <div className="flex items-center text-xs">
          <div className="w-2 h-2 rounded-full bg-green-500 mr-2 animate-pulse"></div>
          <span className="text-gray-600">Live Data</span>
        </div>
      </div>
    </div>
  );
};

export default EVRouteMap;