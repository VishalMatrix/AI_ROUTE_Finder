import React, { useState, useEffect } from "react";
import {
  BarChart3,
  MapPin,
  TrendingUp,
  Users,
  Zap,
  Lock,
  Shield,
  DollarSign,
  Eye,
  EyeOff,
} from "lucide-react";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  LineChart,
  Line,
  PieChart,
  Pie,
  Cell,
  Area,
  AreaChart,
} from "recharts";

const COLORS = ["#0088FE", "#00C49F", "#FFBB28", "#FF8042", "#8884D8"];

export function BusinessTab({ analytics: basicAnalytics }) {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [authError, setAuthError] = useState("");
  const [analytics, setAnalytics] = useState(null);
  const [loading, setLoading] = useState(false);
  const [selectedLocation, setSelectedLocation] = useState({
    lat: 37.7749,
    lng: -122.4194,
  });
  const [radius, setRadius] = useState(10);

  // Company password - in real app this would be env variable
  const COMPANY_PASSWORD = "EV2024Analytics";

  const handleAuthentication = () => {
    if (password === COMPANY_PASSWORD) {
      setIsAuthenticated(true);
      setAuthError("");
      fetchAnalytics();
    } else {
      setAuthError("Invalid company password. Access denied.");
    }
  };

  const fetchAnalytics = async () => {
    setLoading(true);
    try {
      const response = await fetch(
        `/api/business-analytics?lat=${selectedLocation.lat}&lng=${selectedLocation.lng}&radius=${radius}`,
      );
      if (response.ok) {
        const data = await response.json();
        setAnalytics(data.analytics);
      }
    } catch (error) {
      console.error("Error fetching analytics:", error);
    }
    setLoading(false);
  };

  // Authentication screen
  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-gray-900 via-gray-800 to-blue-900 flex items-center justify-center p-6">
        <div className="bg-white/10 backdrop-blur-lg rounded-2xl border border-white/20 p-8 max-w-md w-full shadow-2xl">
          <div className="text-center mb-8">
            <Shield className="w-16 h-16 text-blue-400 mx-auto mb-4" />
            <h2 className="text-3xl font-bold text-white mb-2">
              Secure Access
            </h2>
            <p className="text-gray-300">Business Analytics Dashboard</p>
            <div className="bg-red-500/20 border border-red-500/30 rounded-lg p-3 mt-4">
              <Lock className="w-5 h-5 text-red-400 inline mr-2" />
              <span className="text-red-300 text-sm font-medium">
                Confidential Business Intelligence
              </span>
            </div>
          </div>

          <div className="space-y-6">
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Company Access Password
              </label>
              <div className="relative">
                <input
                  type={showPassword ? "text" : "password"}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  onKeyPress={(e) =>
                    e.key === "Enter" && handleAuthentication()
                  }
                  placeholder="Enter company password"
                  className="w-full px-4 py-3 bg-gray-800/50 border border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-white placeholder-gray-400"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-white transition-colors"
                >
                  {showPassword ? (
                    <EyeOff className="w-5 h-5" />
                  ) : (
                    <Eye className="w-5 h-5" />
                  )}
                </button>
              </div>
            </div>

            {authError && (
              <div className="bg-red-500/20 border border-red-500/30 rounded-lg p-3">
                <p className="text-red-300 text-sm">{authError}</p>
              </div>
            )}

            <button
              onClick={handleAuthentication}
              className="w-full bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white py-3 px-4 rounded-lg font-medium transition-all duration-200 shadow-lg hover:shadow-xl"
            >
              Access Analytics Dashboard
            </button>

            <p className="text-xs text-gray-400 text-center">
              This dashboard contains proprietary business intelligence and
              revenue projections. Unauthorized access is prohibited.
            </p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-8 bg-gray-50 min-h-screen p-6">
      {/* Header */}
      <div className="bg-gradient-to-r from-blue-900 to-purple-900 rounded-2xl p-8 text-white shadow-xl">
        <div className="flex justify-between items-center">
          <div>
            <h2 className="text-4xl font-bold mb-4">
              Business Intelligence Dashboard
            </h2>
            <p className="text-blue-200 text-lg">
              Strategic charging station placement & revenue optimization
            </p>
          </div>
          <div className="text-right">
            <div className="bg-green-500/20 border border-green-400/30 rounded-lg p-3">
              <Shield className="w-6 h-6 text-green-400 inline mr-2" />
              <span className="text-green-300 font-medium">Authenticated</span>
            </div>
            <button
              onClick={() => setIsAuthenticated(false)}
              className="mt-2 text-blue-200 hover:text-white text-sm underline"
            >
              Sign Out
            </button>
          </div>
        </div>

        {/* Location Controls */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-6 bg-white/10 rounded-xl p-4">
          <div>
            <label className="block text-sm font-medium text-blue-200 mb-2">
              Latitude
            </label>
            <input
              type="number"
              step="0.000001"
              value={selectedLocation.lat}
              onChange={(e) =>
                setSelectedLocation({
                  ...selectedLocation,
                  lat: parseFloat(e.target.value),
                })
              }
              className="w-full px-3 py-2 bg-gray-800/50 border border-gray-600 rounded-lg text-white"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-blue-200 mb-2">
              Longitude
            </label>
            <input
              type="number"
              step="0.000001"
              value={selectedLocation.lng}
              onChange={(e) =>
                setSelectedLocation({
                  ...selectedLocation,
                  lng: parseFloat(e.target.value),
                })
              }
              className="w-full px-3 py-2 bg-gray-800/50 border border-gray-600 rounded-lg text-white"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-blue-200 mb-2">
              Radius: {radius} miles
            </label>
            <input
              type="range"
              min="5"
              max="50"
              value={radius}
              onChange={(e) => setRadius(parseInt(e.target.value))}
              className="w-full"
            />
          </div>
        </div>

        <button
          onClick={fetchAnalytics}
          disabled={loading}
          className="mt-4 bg-white/20 hover:bg-white/30 text-white px-6 py-2 rounded-lg font-medium transition-all disabled:opacity-50"
        >
          {loading ? "Analyzing..." : "Run Market Analysis"}
        </button>
      </div>

      {analytics && (
        <>
          {/* Key Metrics */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            <div className="bg-white rounded-xl shadow-lg p-6 border-l-4 border-blue-500">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">
                    Market Saturation
                  </p>
                  <p className="text-2xl font-bold text-gray-900">
                    {analytics.marketOverview.marketSaturation}
                  </p>
                </div>
                <TrendingUp className="w-8 h-8 text-blue-500" />
              </div>
            </div>

            <div className="bg-white rounded-xl shadow-lg p-6 border-l-4 border-green-500">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">
                    Avg Daily Traffic
                  </p>
                  <p className="text-2xl font-bold text-gray-900">
                    {analytics.marketOverview.averageDailyTraffic.toLocaleString()}
                  </p>
                </div>
                <Users className="w-8 h-8 text-green-500" />
              </div>
            </div>

            <div className="bg-white rounded-xl shadow-lg p-6 border-l-4 border-purple-500">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">
                    Existing Stations
                  </p>
                  <p className="text-2xl font-bold text-gray-900">
                    {analytics.marketOverview.totalExistingStations}
                  </p>
                </div>
                <Zap className="w-8 h-8 text-purple-500" />
              </div>
            </div>

            <div className="bg-white rounded-xl shadow-lg p-6 border-l-4 border-orange-500">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Avg ROI</p>
                  <p className="text-2xl font-bold text-gray-900">
                    {analytics.roiProjections.fiveYearROI}%
                  </p>
                </div>
                <DollarSign className="w-8 h-8 text-orange-500" />
              </div>
            </div>
          </div>

          {/* Revenue Projections Chart */}
          <div className="bg-white rounded-xl shadow-lg p-6">
            <h3 className="text-xl font-semibold text-gray-900 mb-6">
              5-Year Revenue Projection
            </h3>
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart
                  data={[
                    {
                      year: "Year 1",
                      revenue: analytics.roiProjections.annualRevenue,
                      profit: analytics.roiProjections.annualProfit,
                      investment: analytics.roiProjections.installationCost,
                    },
                    {
                      year: "Year 2",
                      revenue: analytics.roiProjections.annualRevenue * 1.15,
                      profit: analytics.roiProjections.annualProfit * 1.15,
                      investment: 0,
                    },
                    {
                      year: "Year 3",
                      revenue: analytics.roiProjections.annualRevenue * 1.32,
                      profit: analytics.roiProjections.annualProfit * 1.32,
                      investment: 0,
                    },
                    {
                      year: "Year 4",
                      revenue: analytics.roiProjections.annualRevenue * 1.52,
                      profit: analytics.roiProjections.annualProfit * 1.52,
                      investment: 0,
                    },
                    {
                      year: "Year 5",
                      revenue: analytics.roiProjections.annualRevenue * 1.75,
                      profit: analytics.roiProjections.annualProfit * 1.75,
                      investment: 0,
                    },
                  ]}
                >
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="year" />
                  <YAxis
                    tickFormatter={(value) => `$${(value / 1000).toFixed(0)}K`}
                  />
                  <Tooltip
                    formatter={(value) => [`$${value.toLocaleString()}`, ""]}
                  />
                  <Legend />
                  <Area
                    type="monotone"
                    dataKey="revenue"
                    stackId="1"
                    stroke="#8884d8"
                    fill="#8884d8"
                    fillOpacity={0.6}
                  />
                  <Area
                    type="monotone"
                    dataKey="profit"
                    stackId="1"
                    stroke="#82ca9d"
                    fill="#82ca9d"
                    fillOpacity={0.8}
                  />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Market Competition Analysis */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div className="bg-white rounded-xl shadow-lg p-6">
              <h3 className="text-xl font-semibold text-gray-900 mb-6">
                Market Share by Provider
              </h3>
              <div className="h-64">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={analytics.competitorAnalysis.topProviders.map(
                        (p) => ({ name: p.provider, value: p.stationCount }),
                      )}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      label={({ name, percent }) =>
                        `${name} ${(percent * 100).toFixed(0)}%`
                      }
                      outerRadius={80}
                      fill="#8884d8"
                      dataKey="value"
                    >
                      {analytics.competitorAnalysis.topProviders.map(
                        (entry, index) => (
                          <Cell
                            key={`cell-${index}`}
                            fill={COLORS[index % COLORS.length]}
                          />
                        ),
                      )}
                    </Pie>
                    <Tooltip />
                  </PieChart>
                </ResponsiveContainer>
              </div>
            </div>

            <div className="bg-white rounded-xl shadow-lg p-6">
              <h3 className="text-xl font-semibold text-gray-900 mb-6">
                Charging Speed Distribution
              </h3>
              <div className="h-64">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart
                    data={[
                      {
                        name: "Fast (>150kW)",
                        count:
                          analytics.competitorAnalysis.speedDistribution.fast,
                        color: "#10B981",
                      },
                      {
                        name: "Medium (50-150kW)",
                        count:
                          analytics.competitorAnalysis.speedDistribution.medium,
                        color: "#F59E0B",
                      },
                      {
                        name: "Slow (<50kW)",
                        count:
                          analytics.competitorAnalysis.speedDistribution.slow,
                        color: "#EF4444",
                      },
                    ]}
                  >
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="name" />
                    <YAxis />
                    <Tooltip />
                    <Bar dataKey="count" fill="#8884d8" />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>
          </div>

          {/* Site Recommendations */}
          <div className="bg-white rounded-xl shadow-lg p-6">
            <h3 className="text-xl font-semibold text-gray-900 mb-6 flex items-center">
              <MapPin className="w-6 h-6 mr-2 text-blue-600" />
              Premium Site Recommendations
            </h3>

            {analytics.siteRecommendations.length > 0 ? (
              <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
                {analytics.siteRecommendations
                  .slice(0, 6)
                  .map((site, index) => (
                    <div
                      key={index}
                      className="border border-gray-200 rounded-xl p-6 hover:shadow-lg transition-shadow bg-gradient-to-br from-blue-50 to-indigo-50"
                    >
                      <div className="flex justify-between items-start mb-4">
                        <div className="bg-green-100 text-green-800 text-xs font-bold px-3 py-1 rounded-full">
                          SCORE: {site.score}/100
                        </div>
                        <div className="text-right">
                          <div className="text-sm text-gray-600">
                            Est. Annual Revenue
                          </div>
                          <div className="text-lg font-bold text-green-600">
                            ${(site.estimatedROI * 10000).toLocaleString()}
                          </div>
                        </div>
                      </div>

                      <div className="space-y-3">
                        <div className="grid grid-cols-2 gap-4 text-sm">
                          <div>
                            <span className="text-gray-600">Location:</span>
                            <div className="font-medium">
                              {site.latitude.toFixed(4)},{" "}
                              {site.longitude.toFixed(4)}
                            </div>
                          </div>
                          <div>
                            <span className="text-gray-600">
                              Daily Traffic:
                            </span>
                            <div className="font-medium text-blue-600">
                              {site.dailyTraffic.toLocaleString()}
                            </div>
                          </div>
                        </div>

                        <div className="grid grid-cols-2 gap-4 text-sm">
                          <div>
                            <span className="text-gray-600">Competition:</span>
                            <div
                              className={`font-medium ${site.competition === 0 ? "text-green-600" : site.competition <= 2 ? "text-yellow-600" : "text-red-600"}`}
                            >
                              {site.competition} nearby
                            </div>
                          </div>
                          <div>
                            <span className="text-gray-600">ROI Estimate:</span>
                            <div className="font-medium text-purple-600">
                              {site.estimatedROI}%
                            </div>
                          </div>
                        </div>

                        <div className="grid grid-cols-2 gap-4 text-sm">
                          <div>
                            <span className="text-gray-600">
                              Recommended Ports:
                            </span>
                            <div className="font-medium">
                              {site.recommendedPorts} ports
                            </div>
                          </div>
                          <div>
                            <span className="text-gray-600">Dwell Time:</span>
                            <div className="font-medium">
                              {site.dwellTime} min
                            </div>
                          </div>
                        </div>

                        {site.gridCapacity > 0 && (
                          <div className="text-sm">
                            <span className="text-gray-600">
                              Grid Capacity:
                            </span>
                            <div className="font-medium text-orange-600">
                              {site.gridCapacity} kW available
                            </div>
                          </div>
                        )}

                        {/* Investment Summary */}
                        <div className="border-t pt-3 mt-3 bg-white rounded-lg p-3 -mx-3">
                          <div className="text-xs text-gray-600 mb-2">
                            Investment Summary:
                          </div>
                          <div className="grid grid-cols-2 gap-2 text-xs">
                            <div>
                              Setup Cost:{" "}
                              <span className="font-bold text-red-600">
                                $150k
                              </span>
                            </div>
                            <div>
                              Payback:{" "}
                              <span className="font-bold text-green-600">
                                {(150000 / (site.estimatedROI * 1000)).toFixed(
                                  1,
                                )}{" "}
                                years
                              </span>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
              </div>
            ) : (
              <div className="text-center py-12">
                <MapPin className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                <h4 className="text-lg font-medium text-gray-900 mb-2">
                  No Optimal Locations Found
                </h4>
                <p className="text-gray-600">
                  Try adjusting the search radius or location
                </p>
              </div>
            )}
          </div>

          {/* Financial Summary */}
          <div className="bg-gradient-to-r from-green-900 to-emerald-900 rounded-xl p-8 text-white">
            <h3 className="text-2xl font-bold mb-6">
              Financial Projections Summary
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
              <div className="text-center">
                <div className="text-3xl font-bold text-green-300">
                  ${analytics.roiProjections.installationCost.toLocaleString()}
                </div>
                <div className="text-green-100">Initial Investment</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-blue-300">
                  ${analytics.roiProjections.annualRevenue.toLocaleString()}
                </div>
                <div className="text-blue-100">Annual Revenue</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-yellow-300">
                  {analytics.roiProjections.paybackPeriodYears} years
                </div>
                <div className="text-yellow-100">Payback Period</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-purple-300">
                  {analytics.roiProjections.fiveYearROI}%
                </div>
                <div className="text-purple-100">5-Year ROI</div>
              </div>
            </div>
          </div>
        </>
      )}
    </div>
  );
}

export default BusinessTab;
