import React from 'react';

export function Header({ activeTab, setActiveTab }) {
  return (
    <header className="bg-white shadow-sm border-b border-gray-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center py-6">
          <div className="flex items-center">
            <h1 className="text-3xl font-bold text-gray-900">
              EV Route Optimizer
            </h1>
          </div>
          
          <nav className="flex space-x-8">
            <button
              onClick={() => setActiveTab('driver')}
              className={`px-4 py-2 rounded-lg font-medium transition-colors ${
                activeTab === 'driver'
                  ? 'bg-blue-100 text-blue-700'
                  : 'text-gray-600 hover:text-gray-900 hover:bg-gray-100'
              }`}
            >
              Driver Tools
            </button>
            <button
              onClick={() => setActiveTab('business')}
              className={`px-4 py-2 rounded-lg font-medium transition-colors ${
                activeTab === 'business'
                  ? 'bg-blue-100 text-blue-700'
                  : 'text-gray-600 hover:text-gray-900 hover:bg-gray-100'
              }`}
            >
              Business Analytics
            </button>
          </nav>
        </div>
      </div>
    </header>
  );
}

export default Header;