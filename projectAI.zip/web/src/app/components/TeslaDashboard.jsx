import React, { useState, useEffect } from "react";
import { TeslaHeader } from "./TeslaHeader";
import { TeslaLeftSidebar } from "./TeslaLeftSidebar";
import { TeslaMapView } from "./TeslaMapView";
import { TeslaRightSidebar } from "./TeslaRightSidebar";
import { TeslaControls } from "./TeslaControls";

export function TeslaDashboard({
  vehicles,
  stations,
  analytics,
  activeTab,
  setActiveTab,
}) {
  const [selectedVehicle, setSelectedVehicle] = useState(null);
  const [destination, setDestination] = useState("");
  const [destinationCoords, setDestinationCoords] = useState(null);
  const [batteryLevel, setBatteryLevel] = useState(85);
  const [currentRoute, setCurrentRoute] = useState(null);
  const [batteryThreshold, setBatteryThreshold] = useState(20);
  const [mapCenter, setMapCenter] = useState({ lat: 37.7749, lng: -122.4194 });
  const [currentLocation, setCurrentLocation] = useState({
    lat: 37.7749,
    lng: -122.4194,
  });
  const [routeLoading, setRouteLoading] = useState(false);
  const [routeError, setRouteError] = useState(null);
  const [showRestStops, setShowRestStops] = useState(false);
  const [showParkingInfo, setShowParkingInfo] = useState(false);
  // Add new notification states
  const [notifications, setNotifications] = useState([]);
  const [lowBatteryAlert, setLowBatteryAlert] = useState(null);
  const [alertDismissed, setAlertDismissed] = useState(false);

  // Set initial selected vehicle when vehicles are loaded
  useEffect(() => {
    if (vehicles && vehicles.length > 0 && !selectedVehicle) {
      setSelectedVehicle(vehicles[0]);
    }
  }, [vehicles, selectedVehicle]);

  // Get current location
  useEffect(() => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          const coords = {
            lat: position.coords.latitude,
            lng: position.coords.longitude,
          };
          setMapCenter(coords);
          setCurrentLocation(coords);
        },
        (error) => {
          console.log("Geolocation error:", error);
        },
      );
    }
  }, []);

  const calculateRoute = async () => {
    if (!destinationCoords || !selectedVehicle || !currentLocation) return;
    try {
      setRouteLoading(true);
      setRouteError(null);
      const response = await fetch("/api/route-optimization", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          startLat: currentLocation.lat,
          startLng: currentLocation.lng,
          endLat: destinationCoords.lat,
          endLng: destinationCoords.lng,
          vehicleModelId: selectedVehicle.id,
          batteryPercent: batteryLevel,
          minBatteryThreshold: batteryThreshold,
        }),
      });
      if (!response.ok)
        throw new Error(`Route calculation failed: ${response.status}`);
      const data = await response.json();
      setCurrentRoute(data.route);
    } catch (error) {
      console.error("Error calculating route:", error);
      setRouteError("Failed to calculate route. Please try again.");
    } finally {
      setRouteLoading(false);
    }
  };

  // Recalculate route when destination, vehicle, or battery settings change
  useEffect(() => {
    if (destinationCoords && selectedVehicle && currentLocation) {
      calculateRoute();
    }
  }, [
    destinationCoords,
    selectedVehicle,
    batteryLevel,
    batteryThreshold,
    currentLocation,
  ]);

  // Check for low battery and find nearest station
  useEffect(() => {
    if (
      batteryLevel <= batteryThreshold &&
      stations &&
      stations.length > 0 &&
      currentLocation &&
      !alertDismissed
    ) {
      const nearestStation = findNearestStation(currentLocation, stations);
      if (nearestStation && !lowBatteryAlert) {
        setLowBatteryAlert({
          id: Date.now(),
          type: "lowBattery",
          station: nearestStation,
          batteryLevel,
          threshold: batteryThreshold,
        });
      }
    } else if (batteryLevel > batteryThreshold) {
      setLowBatteryAlert(null);
      setAlertDismissed(false); // Reset dismissed state when battery goes above threshold
    }
  }, [
    batteryLevel,
    batteryThreshold,
    stations,
    currentLocation,
    alertDismissed,
  ]);

  // Helper functions
  const findNearestStation = (location, stations) => {
    if (!stations || stations.length === 0) return null;

    let nearest = stations[0];
    let minDistance = calculateDistance(
      location.lat,
      location.lng,
      nearest.latitude,
      nearest.longitude,
    );

    stations.forEach((station) => {
      const distance = calculateDistance(
        location.lat,
        location.lng,
        station.latitude,
        station.longitude,
      );
      if (distance < minDistance) {
        minDistance = distance;
        nearest = station;
      }
    });

    return { ...nearest, distance: minDistance };
  };

  const calculateDistance = (lat1, lng1, lat2, lng2) => {
    const R = 3959; // Earth's radius in miles
    const dLat = ((lat2 - lat1) * Math.PI) / 180;
    const dLng = ((lng2 - lng1) * Math.PI) / 180;
    const a =
      Math.sin(dLat / 2) * Math.sin(dLat / 2) +
      Math.cos((lat1 * Math.PI) / 180) *
        Math.cos((lat2 * Math.PI) / 180) *
        Math.sin(dLng / 2) *
        Math.sin(dLng / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    return R * c;
  };

  const addNotification = (notification) => {
    const id = Date.now();
    const newNotification = { ...notification, id };
    setNotifications((prev) => [...prev, newNotification]);

    // Auto dismiss after 5 seconds
    setTimeout(() => {
      setNotifications((prev) => prev.filter((n) => n.id !== id));
    }, 5000);

    return id;
  };

  const dismissNotification = (id) => {
    setNotifications((prev) => prev.filter((n) => n.id !== id));
  };

  const handleDestinationChange = (value) => {
    setDestination(value);
    if (!value.trim()) {
      setDestinationCoords(null);
      setCurrentRoute(null);
      return;
    }
    // Simple geocoding for demo
    if (
      value.toLowerCase().includes("los angeles") ||
      value.toLowerCase().includes("la")
    ) {
      setDestinationCoords({ lat: 34.0522, lng: -118.2437 });
    } else if (
      value.toLowerCase().includes("san francisco") ||
      value.toLowerCase().includes("sf")
    ) {
      setDestinationCoords({ lat: 37.7749, lng: -122.4194 });
    } else if (value.toLowerCase().includes("sacramento")) {
      setDestinationCoords({ lat: 38.5816, lng: -121.4944 });
    } else if (value.toLowerCase().includes("san jose")) {
      setDestinationCoords({ lat: 37.3382, lng: -121.8863 });
    }
  };

  const handleMapClick = (event) => {
    const lat = event.detail.latLng.lat;
    const lng = event.detail.latLng.lng;
    setDestinationCoords({ lat, lng });

    if (window.google && window.google.maps) {
      const geocoder = new window.google.maps.Geocoder();
      geocoder.geocode({ location: { lat, lng } }, (results, status) => {
        if (status === "OK" && results[0]) {
          setDestination(results[0].formatted_address);
        } else {
          setDestination(`${lat.toFixed(4)}, ${lng.toFixed(4)}`);
        }
      });
    } else {
      setDestination(`${lat.toFixed(4)}, ${lng.toFixed(4)}`);
    }
  };

  const startNavigation = () => {
    if (destinationCoords) {
      addNotification({
        type: "success",
        title: "Navigation Started!",
        message: `Route optimized for your ${selectedVehicle?.make} ${selectedVehicle?.model}`,
        destination: destination,
        icon: "🚗",
      });
      setCurrentRoute((prev) =>
        prev ? { ...prev, navigationStarted: true } : null,
      );
    } else {
      addNotification({
        type: "warning",
        title: "Destination Required",
        message: "Please select a destination first",
        icon: "⚠️",
      });
    }
  };

  // Updated button handlers
  const handleRestStopClick = () => {
    setShowRestStops(true);
    setShowParkingInfo(false);
  };

  const handleParkingClick = () => {
    setShowParkingInfo(true);
    setShowRestStops(false);
  };

  const loading = !vehicles || vehicles.length === 0;

  const restStops = [
    {
      name: "Starbucks Coffee",
      distance: "2.3 mi",
      type: "☕ Coffee",
      hours: "6 AM - 10 PM",
      rating: 4.5,
      chargingAvailable: true,
    },
    {
      name: "McDonald's",
      distance: "1.8 mi",
      type: "🍔 Fast Food",
      hours: "24 Hours",
      rating: 4.2,
      chargingAvailable: false,
    },
    {
      name: "Travel Center Rest Stop",
      distance: "5.1 mi",
      type: "🚻 Rest Area",
      hours: "24 Hours",
      rating: 4.0,
      chargingAvailable: true,
    },
    {
      name: "Shell Station & Mart",
      distance: "3.2 mi",
      type: "⛽ Gas & Snacks",
      hours: "5 AM - 11 PM",
      rating: 4.3,
      chargingAvailable: true,
    },
    {
      name: "Whole Foods Market",
      distance: "4.7 mi",
      type: "🥗 Grocery",
      hours: "8 AM - 9 PM",
      rating: 4.6,
      chargingAvailable: true,
    },
  ];

  const parkingAreas = [
    {
      name: "Downtown Tesla Supercharger",
      distance: "0.8 mi",
      spaces: "8 chargers available",
      security: "🔒 Monitored",
      cost: "$0.28/kWh",
      chargingSpeed: "150kW",
    },
    {
      name: "Premium Shopping Mall",
      distance: "1.2 mi",
      spaces: "45 spots available",
      security: "🔒 Covered Garage",
      cost: "$2.50/hr",
      chargingSpeed: "Level 2",
    },
    {
      name: "Public EV Charging Lot",
      distance: "0.3 mi",
      spaces: "12 EV spots",
      security: "🔓 Open Lot",
      cost: "Free 2hrs",
      chargingSpeed: "50kW",
    },
    {
      name: "Hotel Valet Charging",
      distance: "2.1 mi",
      spaces: "6 premium spots",
      security: "🔒 Valet Service",
      cost: "$15/night",
      chargingSpeed: "Level 2",
    },
  ];

  return (
    <div className="h-screen bg-black text-white flex flex-col relative overflow-hidden">
      <TeslaHeader
        destination={destination}
        routeLoading={routeLoading}
        routeError={routeError}
        onRestStopClick={handleRestStopClick}
        onParkingClick={handleParkingClick}
      />

      <div className="flex-1 flex">
        <TeslaLeftSidebar
          batteryLevel={batteryLevel}
          setBatteryLevel={setBatteryLevel}
          batteryThreshold={batteryThreshold}
          setBatteryThreshold={setBatteryThreshold}
          stations={stations || []}
          selectedVehicle={selectedVehicle}
        />

        <TeslaMapView
          loading={loading}
          mapCenter={mapCenter}
          currentLocation={currentLocation}
          destinationCoords={destinationCoords}
          destination={destination}
          stations={stations || []}
          handleMapClick={handleMapClick}
          currentRoute={currentRoute}
          batteryThreshold={batteryThreshold}
        />

        <TeslaRightSidebar
          destination={destination}
          handleDestinationChange={handleDestinationChange}
          vehicles={vehicles || []}
          selectedVehicle={selectedVehicle}
          setSelectedVehicle={setSelectedVehicle}
          loading={loading}
          startNavigation={startNavigation}
          calculateRoute={calculateRoute}
          destinationCoords={destinationCoords}
          routeLoading={routeLoading}
        />
      </div>

      <TeslaControls activeTab={activeTab} setActiveTab={setActiveTab} />

      {/* Rest Stops Popup */}
      {showRestStops && (
        <div className="absolute inset-0 bg-black bg-opacity-70 flex items-center justify-center z-50">
          <div className="bg-gray-900 rounded-xl p-6 max-w-2xl w-full max-h-[80vh] overflow-y-auto mx-4">
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 bg-orange-500/20 rounded-lg flex items-center justify-center">
                  ☕
                </div>
                <div>
                  <h2 className="text-xl font-bold text-white">
                    Rest Stops Nearby
                  </h2>
                  <p className="text-gray-400 text-sm">
                    Perfect for charging breaks
                  </p>
                </div>
              </div>
              <button
                onClick={() => setShowRestStops(false)}
                className="text-gray-400 hover:text-white text-2xl font-bold"
              >
                ×
              </button>
            </div>

            <div className="space-y-4">
              {restStops.map((stop, index) => (
                <div
                  key={index}
                  className="bg-gray-800 rounded-lg p-4 border border-gray-700"
                >
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center space-x-2 mb-2">
                        <span className="text-lg">
                          {stop.type.split(" ")[0]}
                        </span>
                        <h3 className="font-semibold text-white">
                          {stop.name}
                        </h3>
                        {stop.chargingAvailable && (
                          <span className="px-2 py-1 bg-green-500/20 text-green-400 text-xs rounded-full">
                            ⚡ EV Charging
                          </span>
                        )}
                      </div>
                      <div className="flex items-center space-x-4 text-sm text-gray-300">
                        <span>📍 {stop.distance}</span>
                        <span>🕒 {stop.hours}</span>
                        <span>⭐ {stop.rating}</span>
                      </div>
                    </div>
                    <button className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white text-sm rounded-lg transition-colors">
                      Navigate
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Parking Info Popup */}
      {showParkingInfo && (
        <div className="absolute inset-0 bg-black bg-opacity-70 flex items-center justify-center z-50">
          <div className="bg-gray-900 rounded-xl p-6 max-w-2xl w-full max-h-[80vh] overflow-y-auto mx-4">
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 bg-green-500/20 rounded-lg flex items-center justify-center">
                  🅿️
                </div>
                <div>
                  <h2 className="text-xl font-bold text-white">
                    Secure Parking
                  </h2>
                  <p className="text-gray-400 text-sm">
                    EV-ready parking spots
                  </p>
                </div>
              </div>
              <button
                onClick={() => setShowParkingInfo(false)}
                className="text-gray-400 hover:text-white text-2xl font-bold"
              >
                ×
              </button>
            </div>

            <div className="space-y-4">
              {parkingAreas.map((area, index) => (
                <div
                  key={index}
                  className="bg-gray-800 rounded-lg p-4 border border-gray-700"
                >
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center space-x-2 mb-2">
                        <h3 className="font-semibold text-white">
                          {area.name}
                        </h3>
                        <span className="px-2 py-1 bg-blue-500/20 text-blue-400 text-xs rounded-full">
                          {area.chargingSpeed}
                        </span>
                      </div>
                      <div className="space-y-1 text-sm text-gray-300">
                        <div className="flex items-center space-x-4">
                          <span>📍 {area.distance}</span>
                          <span>🅿️ {area.spaces}</span>
                        </div>
                        <div className="flex items-center space-x-4">
                          <span>{area.security}</span>
                          <span>💰 {area.cost}</span>
                        </div>
                      </div>
                    </div>
                    <button className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white text-sm rounded-lg transition-colors">
                      Navigate
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Low Battery Alert */}
      {lowBatteryAlert && (
        <div className="absolute inset-0 bg-black bg-opacity-80 flex items-center justify-center z-50 notification-backdrop">
          <div className="bg-gradient-to-br from-red-900/90 to-gray-900/90 backdrop-blur-xl rounded-2xl p-8 max-w-md w-full mx-4 border border-red-500/30 shadow-2xl notification-card">
            <div className="flex items-start space-x-4">
              <div className="flex-shrink-0">
                <div className="w-16 h-16 bg-red-500/20 rounded-full flex items-center justify-center animate-pulse">
                  <div className="w-12 h-12 bg-red-500/30 rounded-full flex items-center justify-center">
                    <span className="text-2xl">⚡</span>
                  </div>
                </div>
              </div>
              <div className="flex-1">
                <h2 className="text-2xl font-bold text-white mb-2">
                  ⚠️ Low Battery Alert
                </h2>
                <p className="text-red-200 text-sm mb-4">
                  Battery level is at {lowBatteryAlert.batteryLevel}%, below
                  your {lowBatteryAlert.threshold}% threshold
                </p>

                <div className="bg-black/30 rounded-lg p-4 mb-4 border border-red-500/20">
                  <div className="flex items-center space-x-3 mb-3">
                    <div className="w-8 h-8 bg-blue-500/20 rounded-lg flex items-center justify-center">
                      <span className="text-sm">🔌</span>
                    </div>
                    <div>
                      <h3 className="font-semibold text-white text-sm">
                        Nearest Charging Station
                      </h3>
                      <p className="text-blue-200 text-xs">
                        {lowBatteryAlert.station.name}
                      </p>
                    </div>
                  </div>
                  <div className="space-y-2 text-xs">
                    <div className="flex justify-between">
                      <span className="text-gray-300">Distance:</span>
                      <span className="text-white font-medium">
                        {lowBatteryAlert.station.distance.toFixed(1)} miles
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-300">Charging Speed:</span>
                      <span className="text-green-400 font-medium">
                        {lowBatteryAlert.station.charging_speed_kw}kW
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-300">Provider:</span>
                      <span className="text-white font-medium">
                        {lowBatteryAlert.station.provider}
                      </span>
                    </div>
                  </div>
                </div>

                <div className="flex space-x-3">
                  <button
                    onClick={() => {
                      // Navigate to station
                      const stationName = lowBatteryAlert.station.name;
                      const stationLat = lowBatteryAlert.station.latitude;
                      const stationLng = lowBatteryAlert.station.longitude;

                      // Dismiss alert first
                      setLowBatteryAlert(null);

                      // Then set destination
                      setDestination(stationName);
                      setDestinationCoords({
                        lat: stationLat,
                        lng: stationLng,
                      });

                      // Show confirmation notification
                      addNotification({
                        type: "info",
                        title: "Route to Charging Station",
                        message: `Navigating to ${stationName}`,
                        icon: "🗺️",
                      });
                    }}
                    className="flex-1 bg-blue-600 hover:bg-blue-700 text-white text-sm font-medium py-2 px-4 rounded-lg transition-all duration-200 transform hover:scale-105"
                  >
                    Navigate There
                  </button>
                  <button
                    onClick={() => setLowBatteryAlert(null)}
                    className="px-4 py-2 bg-gray-600 hover:bg-gray-700 text-white text-sm rounded-lg transition-colors"
                  >
                    Dismiss
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Beautiful Notification Container */}
      <div className="fixed top-4 right-4 z-50 space-y-2">
        {notifications.map((notification) => (
          <div
            key={notification.id}
            className="notification-item bg-gray-900/95 backdrop-blur-xl border border-gray-700/50 rounded-xl p-4 min-w-[320px] max-w-md shadow-2xl"
          >
            <div className="flex items-start space-x-3">
              <div
                className={`w-10 h-10 rounded-lg flex items-center justify-center flex-shrink-0 ${
                  notification.type === "success"
                    ? "bg-green-500/20"
                    : notification.type === "warning"
                      ? "bg-yellow-500/20"
                      : notification.type === "error"
                        ? "bg-red-500/20"
                        : "bg-blue-500/20"
                }`}
              >
                <span className="text-lg">{notification.icon}</span>
              </div>
              <div className="flex-1 min-w-0">
                <h4 className="text-white font-semibold text-sm mb-1">
                  {notification.title}
                </h4>
                <p className="text-gray-300 text-xs leading-relaxed">
                  {notification.message}
                </p>
                {notification.destination && (
                  <p className="text-blue-400 text-xs mt-1 font-medium">
                    📍 {notification.destination}
                  </p>
                )}
              </div>
              <button
                onClick={() => dismissNotification(notification.id)}
                className="text-gray-400 hover:text-white text-lg font-bold flex-shrink-0 ml-2 transform hover:scale-110 transition-all"
              >
                ×
              </button>
            </div>
          </div>
        ))}
      </div>

      <style jsx global>{`
        .slider {
          background: linear-gradient(to right, #ef4444 0%, #f59e0b 50%, #10b981 100%);
        }
        .slider::-webkit-slider-thumb {
          -webkit-appearance: none;
          appearance: none;
          width: 16px;
          height: 16px;
          border-radius: 50%;
          background: #ffffff;
          cursor: pointer;
          box-shadow: 0 2px 4px rgba(0,0,0,0.2);
        }
        .slider::-moz-range-thumb {
          width: 16px;
          height: 16px;
          border-radius: 50%;
          background: #ffffff;
          cursor: pointer;
          border: none;
          box-shadow: 0 2px 4px rgba(0,0,0,0.2);
        }
        
        /* Notification Animations */
        .notification-backdrop {
          animation: fadeIn 0.3s ease-out;
        }
        
        .notification-card {
          animation: slideInScale 0.4s cubic-bezier(0.16, 1, 0.3, 1);
        }
        
        .notification-item {
          animation: slideInRight 0.4s cubic-bezier(0.16, 1, 0.3, 1);
          transition: all 0.3s ease;
        }
        
        .notification-item:hover {
          transform: translateX(-4px) scale(1.02);
          box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.5);
        }
        
        @keyframes fadeIn {
          from {
            opacity: 0;
          }
          to {
            opacity: 1;
          }
        }
        
        @keyframes slideInScale {
          from {
            opacity: 0;
            transform: translateY(20px) scale(0.95);
          }
          to {
            opacity: 1;
            transform: translateY(0) scale(1);
          }
        }
        
        @keyframes slideInRight {
          from {
            opacity: 0;
            transform: translateX(100px) scale(0.9);
          }
          to {
            opacity: 1;
            transform: translateX(0) scale(1);
          }
        }
      `}</style>
    </div>
  );
}

export default TeslaDashboard;
