import React from "react";
import { APIProvider, Map, Marker } from "@vis.gl/react-google-maps";
import { Loader, AlertTriangle } from "lucide-react";
import { mapStyles } from "@/utils/mapStyles";
import { TeslaRouteOverlay } from "./TeslaRouteOverlay";

const GOOGLE_MAPS_API_KEY = process.env.NEXT_PUBLIC_GOOGLE_MAPS_API_KEY;

export function TeslaMapView({
  loading,
  mapCenter,
  currentLocation,
  destinationCoords,
  destination,
  stations,
  handleMapClick,
  currentRoute,
  batteryThreshold,
}) {
  if (!GOOGLE_MAPS_API_KEY) {
    return (
      <div className="flex-1 bg-gray-800 relative flex items-center justify-center">
        <div className="text-center p-6 bg-gray-900 rounded-lg border border-red-500/30">
          <AlertTriangle className="w-12 h-12 text-red-400 mx-auto mb-4" />
          <h3 className="text-lg font-semibold text-red-400 mb-2">
            Map Service Unavailable
          </h3>
          <p className="text-gray-300 text-sm">
            Google Maps API key is required. Please configure
            NEXT_PUBLIC_GOOGLE_MAPS_API_KEY in your environment.
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="flex-1 bg-gray-800 relative">
      <APIProvider apiKey={GOOGLE_MAPS_API_KEY}>
        <Map
          style={{ width: "100%", height: "100%" }}
          center={mapCenter}
          zoom={12}
          gestureHandling="greedy"
          disableDefaultUI={true}
          styles={mapStyles}
          onClick={handleMapClick}
          options={{
            zoomControl: true,
            mapTypeControl: false,
            scaleControl: false,
            streetViewControl: false,
            rotateControl: false,
            fullscreenControl: false,
          }}
        >
          {/* Current Location Marker */}
          <Marker
            position={currentLocation}
            title="Current Location"
            icon={{
              url: `data:image/svg+xml;charset=UTF-8,${encodeURIComponent(
                `<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><circle cx="12" cy="12" r="8" fill="#10b981" stroke="#ffffff" stroke-width="3"/><circle cx="12" cy="12" r="3" fill="#ffffff"/></svg>`,
              )}`,
              scaledSize: { width: 24, height: 24 },
              anchor: { x: 12, y: 12 },
            }}
          />

          {/* Destination Marker */}
          {destinationCoords && (
            <Marker
              position={destinationCoords}
              title={`Destination: ${destination}`}
              icon={{
                url: `data:image/svg+xml;charset=UTF-8,${encodeURIComponent(
                  `<svg width="32" height="32" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><circle cx="12" cy="12" r="10" fill="#ef4444" stroke="#ffffff" stroke-width="2"/><path d="M12 8L12 16M8 12L16 12" stroke="#ffffff" stroke-width="3" stroke-linecap="round"/></svg>`,
                )}`,
                scaledSize: { width: 32, height: 32 },
                anchor: { x: 16, y: 16 },
              }}
            />
          )}

          {/* Charging Station Markers */}
          {stations &&
            stations.map &&
            stations.map((station) => (
              <Marker
                key={station.id}
                position={{
                  lat: parseFloat(station.latitude),
                  lng: parseFloat(station.longitude),
                }}
                title={`${station.name} - ${station.charging_speed_kw}kW`}
                icon={{
                  url: `data:image/svg+xml;charset=UTF-8,${encodeURIComponent(
                    `<svg width="28" height="28" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><circle cx="12" cy="12" r="10" fill="#3b82f6" stroke="#ffffff" stroke-width="2"/><path d="M12 6L12 18M8 10L16 14" stroke="#ffffff" stroke-width="2.5" stroke-linecap="round"/></svg>`,
                  )}`,
                  scaledSize: { width: 28, height: 28 },
                  anchor: { x: 14, y: 14 },
                }}
              />
            ))}
        </Map>
      </APIProvider>

      <div className="absolute top-4 left-4 bg-black bg-opacity-80 rounded-lg p-3 max-w-xs">
        <p className="text-xs text-gray-300">
          Click on the map to set your destination, or use the search box on the
          right.
        </p>
      </div>

      {loading && (
        <div className="absolute inset-0 bg-gray-900 bg-opacity-90 flex items-center justify-center">
          <div className="text-center">
            <Loader className="w-8 h-8 animate-spin text-blue-400 mx-auto mb-3" />
            <p className="text-gray-400">Loading map and stations...</p>
          </div>
        </div>
      )}

      <TeslaRouteOverlay
        currentRoute={currentRoute}
        batteryThreshold={batteryThreshold}
      />
    </div>
  );
}
export default TeslaMapView;
