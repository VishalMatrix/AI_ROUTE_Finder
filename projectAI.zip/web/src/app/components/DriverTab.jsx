import React, { useState } from 'react';
import { MapPin, Battery, Clock, Zap } from 'lucide-react';

export function DriverTab({ vehicles, stations }) {
  const [selectedVehicle, setSelectedVehicle] = useState(null);
  const [startLocation, setStartLocation] = useState('');
  const [endLocation, setEndLocation] = useState('');
  const [batteryLevel, setBatteryLevel] = useState(80);

  const handleRouteCalculation = async () => {
    if (!selectedVehicle || !startLocation || !endLocation) {
      alert('Please fill in all fields');
      return;
    }

    try {
      const response = await fetch('/api/route-optimization', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          vehicleId: selectedVehicle.id,
          startLocation,
          endLocation,
          batteryLevel,
        }),
      });

      if (!response.ok) {
        throw new Error('Failed to calculate route');
      }

      const result = await response.json();
      console.log('Route calculation result:', result);
    } catch (error) {
      console.error('Error calculating route:', error);
      alert('Failed to calculate route');
    }
  };

  return (
    <div className="space-y-8">
      <div className="text-center">
        <h2 className="text-3xl font-bold text-gray-900 mb-4">
          Plan Your EV Journey
        </h2>
        <p className="text-lg text-gray-600">
          Find the optimal route with charging stops for your electric vehicle
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Route Planning Form */}
        <div className="bg-white rounded-xl shadow-lg p-6">
          <h3 className="text-xl font-semibold text-gray-900 mb-6">
            Route Planning
          </h3>
          
          <div className="space-y-4">
            {/* Vehicle Selection */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Select Vehicle
              </label>
              <select
                value={selectedVehicle?.id || ''}
                onChange={(e) => {
                  const vehicle = vehicles.find(v => v.id === parseInt(e.target.value));
                  setSelectedVehicle(vehicle);
                }}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              >
                <option value="">Choose your vehicle</option>
                {vehicles.map((vehicle) => (
                  <option key={vehicle.id} value={vehicle.id}>
                    {vehicle.make} {vehicle.model} ({vehicle.range_miles} miles range)
                  </option>
                ))}
              </select>
            </div>

            {/* Start Location */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                <MapPin className="inline w-4 h-4 mr-1" />
                Start Location
              </label>
              <input
                type="text"
                value={startLocation}
                onChange={(e) => setStartLocation(e.target.value)}
                placeholder="Enter starting address"
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>

            {/* End Location */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                <MapPin className="inline w-4 h-4 mr-1" />
                Destination
              </label>
              <input
                type="text"
                value={endLocation}
                onChange={(e) => setEndLocation(e.target.value)}
                placeholder="Enter destination address"
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>

            {/* Battery Level */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                <Battery className="inline w-4 h-4 mr-1" />
                Current Battery Level: {batteryLevel}%
              </label>
              <input
                type="range"
                min="0"
                max="100"
                value={batteryLevel}
                onChange={(e) => setBatteryLevel(parseInt(e.target.value))}
                className="w-full"
              />
            </div>

            <button
              onClick={handleRouteCalculation}
              className="w-full bg-blue-600 text-white py-3 px-4 rounded-lg hover:bg-blue-700 transition-colors font-medium"
            >
              Calculate Optimal Route
            </button>
          </div>
        </div>

        {/* Nearby Charging Stations */}
        <div className="bg-white rounded-xl shadow-lg p-6">
          <h3 className="text-xl font-semibold text-gray-900 mb-6">
            Nearby Charging Stations
          </h3>
          
          <div className="space-y-4 max-h-96 overflow-y-auto">
            {stations.map((station) => (
              <div key={station.id} className="border border-gray-200 rounded-lg p-4">
                <div className="flex justify-between items-start mb-2">
                  <h4 className="font-medium text-gray-900">{station.name}</h4>
                  <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                    station.status === 'active' 
                      ? 'bg-green-100 text-green-800' 
                      : 'bg-red-100 text-red-800'
                  }`}>
                    {station.status}
                  </span>
                </div>
                
                <p className="text-sm text-gray-600 mb-3">{station.address}</p>
                
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div className="flex items-center">
                    <Zap className="w-4 h-4 mr-1 text-yellow-500" />
                    <span>{station.charging_speed_kw} kW</span>
                  </div>
                  <div className="flex items-center">
                    <Clock className="w-4 h-4 mr-1 text-blue-500" />
                    <span>{station.available_ports}/{station.total_ports} available</span>
                  </div>
                </div>
                
                {station.cost_per_kwh && (
                  <div className="mt-2 text-sm text-gray-600">
                    ${station.cost_per_kwh}/kWh
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

export default DriverTab;