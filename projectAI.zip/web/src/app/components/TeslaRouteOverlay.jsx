import React from "react";
import { motion } from "motion/react";
import { AlertTriangle } from "lucide-react";

export function TeslaRouteOverlay({ currentRoute, batteryThreshold }) {
  if (!currentRoute) return null;

  return (
    <motion.div
      className="absolute bottom-4 left-4 right-4"
      initial={{ opacity: 0, y: 50 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
    >
      <div className="bg-black bg-opacity-80 rounded-lg p-4 backdrop-blur-sm">
        <div className="grid grid-cols-4 gap-4 text-center">
          <div>
            <div className="text-sm text-gray-400">Total Distance</div>
            <div className="text-lg font-semibold">
              {currentRoute.distance} mi
            </div>
          </div>
          <div>
            <div className="text-sm text-gray-400">Charging Stops</div>
            <div className="text-lg font-semibold">
              {currentRoute.chargingStops?.length || 0} stops
            </div>
          </div>
          <div>
            <div className="text-sm text-gray-400">Arrival Battery</div>
            <div
              className={`text-lg font-semibold ${
                currentRoute.batteryAtDestination >= batteryThreshold
                  ? "text-green-400"
                  : "text-yellow-400"
              }`}
            >
              {currentRoute.batteryAtDestination}%
            </div>
          </div>
          <div>
            <div className="text-sm text-gray-400">Total Time</div>
            <div className="text-lg font-semibold">
              {Math.floor(currentRoute.totalTravelTime / 60)}h{" "}
              {currentRoute.totalTravelTime % 60}m
            </div>
          </div>
        </div>

        {/* Charging Stops Details */}
        {currentRoute.chargingStops && currentRoute.chargingStops.length > 0 && (
          <div className="mt-3 pt-3 border-t border-gray-600">
            <div className="text-xs text-gray-400 mb-2">
              Charging Stops Required:
            </div>
            {currentRoute.chargingStops.map((stop, index) => (
              <div
                key={index}
                className="text-xs text-gray-300 flex justify-between"
              >
                <span>{stop.station.name}</span>
                <span>{stop.chargingTimeMinutes} min</span>
              </div>
            ))}
          </div>
        )}

        {/* Recommendations */}
        {currentRoute.recommendations && currentRoute.recommendations.length > 0 && (
          <div className="mt-3 pt-3 border-t border-gray-600">
            {currentRoute.recommendations.map((rec, index) => (
              <div
                key={index}
                className={`text-xs flex items-center space-x-1 ${
                  rec.type === "warning"
                    ? "text-yellow-400"
                    : rec.type === "tip"
                    ? "text-blue-400"
                    : "text-gray-300"
                }`}
              >
                <AlertTriangle className="w-3 h-3" />
                <span>{rec.message}</span>
              </div>
            ))}
          </div>
        )}
      </div>
    </motion.div>
  );
}
