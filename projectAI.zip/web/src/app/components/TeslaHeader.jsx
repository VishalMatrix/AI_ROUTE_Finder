import React from "react";
import {
  Play,
  Navigation,
  Loader,
  Coffee,
  ParkingCircle,
  MapPin,
} from "lucide-react";
import { motion } from "motion/react";

export function TeslaHeader({
  destination,
  routeLoading,
  routeError,
  onRestStopClick,
  onParkingClick,
}) {
  return (
    <>
      {/* Top Status Bar */}
      <div className="flex justify-between items-center p-4 bg-gray-900 border-b border-gray-700">
        <div className="flex items-center space-x-4">
          <div className="flex items-center space-x-3">
            <motion.div
              animate={{ rotate: 360 }}
              transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
              className="w-6 h-6 bg-gradient-to-r from-blue-500 to-purple-600 rounded-full flex items-center justify-center"
            >
              <Play className="w-3 h-3 text-white" fill="white" />
            </motion.div>
            <div>
              <span className="text-lg font-bold bg-gradient-to-r from-blue-400 to-purple-400 bg-clip-text text-transparent">
                Flux Way
              </span>
              <div className="text-xs text-gray-400">EV Route Intelligence</div>
            </div>
          </div>
        </div>

        {/* Rest Stop & Parking Controls */}
        <div className="flex items-center space-x-3">
          <motion.button
            onClick={onRestStopClick}
            className="flex items-center space-x-2 px-3 py-2 bg-orange-600/20 hover:bg-orange-600/30 border border-orange-500/40 rounded-lg transition-all duration-300 group"
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            <Coffee className="w-4 h-4 text-orange-400 group-hover:text-orange-300" />
            <span className="text-sm text-orange-300 font-medium">
              Rest Stops
            </span>
          </motion.button>

          <motion.button
            onClick={onParkingClick}
            className="flex items-center space-x-2 px-3 py-2 bg-green-600/20 hover:bg-green-600/30 border border-green-500/40 rounded-lg transition-all duration-300 group"
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            <ParkingCircle className="w-4 h-4 text-green-400 group-hover:text-green-300" />
            <span className="text-sm text-green-300 font-medium">Parking</span>
          </motion.button>

          <motion.button
            className="flex items-center space-x-2 px-3 py-2 bg-blue-600/20 hover:bg-blue-600/30 border border-blue-500/40 rounded-lg transition-all duration-300 group"
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            <MapPin className="w-4 h-4 text-blue-400 group-hover:text-blue-300" />
            <span className="text-sm text-blue-300 font-medium">POI</span>
          </motion.button>
        </div>
      </div>

      {/* Navigation Header */}
      {destination && (
        <div className="bg-gradient-to-r from-gray-800 to-gray-900 p-4 border-b border-gray-700">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <motion.div
                animate={{ rotate: [0, 360] }}
                transition={{ duration: 2, repeat: Infinity, ease: "linear" }}
                className="w-6 h-6 bg-blue-500 rounded-full flex items-center justify-center"
              >
                <Navigation className="w-3 h-3 text-white" />
              </motion.div>
              <div>
                <span className="text-lg font-semibold text-white">
                  Navigating to {destination}
                </span>
                {routeLoading && (
                  <div className="flex items-center space-x-2 mt-1">
                    <Loader className="w-3 h-3 animate-spin text-blue-400" />
                    <span className="text-xs text-blue-400">
                      Optimizing route...
                    </span>
                  </div>
                )}
              </div>
            </div>

            {/* Quick Actions */}
            <div className="flex items-center space-x-2">
              <motion.div
                className="px-3 py-1 bg-green-500/20 border border-green-500/40 rounded-full"
                animate={{ opacity: [0.7, 1, 0.7] }}
                transition={{ duration: 2, repeat: Infinity }}
              >
                <span className="text-xs text-green-400 font-medium">
                  ● LIVE
                </span>
              </motion.div>

              <motion.button
                className="px-3 py-1 bg-orange-500/20 hover:bg-orange-500/30 border border-orange-500/40 rounded-full transition-colors"
                whileHover={{ scale: 1.05 }}
                onClick={onRestStopClick}
              >
                <span className="text-xs text-orange-400 font-medium">
                  Find Rest Areas
                </span>
              </motion.button>
            </div>
          </div>

          {routeError && (
            <motion.div
              className="mt-3 p-3 bg-red-900/40 border border-red-500/40 rounded-lg"
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
            >
              <div className="text-red-400 text-sm font-medium">
                ⚠️ {routeError}
              </div>
            </motion.div>
          )}
        </div>
      )}
    </>
  );
}

export default TeslaHeader;
