import React from "react";
import { motion } from "motion/react";
import { Car, Zap, MapPin } from "lucide-react";

export function TeslaControls({ activeTab, setActiveTab }) {
  return (
    <div className="bg-gray-900 p-4">
      <div className="flex items-center justify-between">
        <div className="flex space-x-6">
          <motion.button
            className="p-2 rounded-full hover:bg-gray-800 transition-colors"
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.9 }}
          >
            <Car className="w-5 h-5" />
          </motion.button>
          <motion.button
            className="p-2 rounded-full hover:bg-gray-800 transition-colors"
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.9 }}
          >
            <Zap className="w-5 h-5" />
          </motion.button>
          <motion.button
            className="p-2 rounded-full hover:bg-gray-800 transition-colors"
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.9 }}
          >
            <MapPin className="w-5 h-5" />
          </motion.button>
        </div>

        <div className="flex items-center space-x-4">
          <button
            onClick={() => setActiveTab("driver")}
            className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
              activeTab === "driver"
                ? "bg-blue-600 text-white"
                : "text-gray-400 hover:text-white"
            }`}
          >
            Driver
          </button>
          <button
            onClick={() => setActiveTab("business")}
            className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
              activeTab === "business"
                ? "bg-blue-600 text-white"
                : "text-gray-400 hover:text-white"
            }`}
          >
            Analytics
          </button>
        </div>
      </div>
    </div>
  );
}

export default TeslaControls;
