import React, { useState } from "react";
import { motion } from "motion/react";

// Unit Selection Component
const UnitSelector = ({ unit, onUnitChange }) => (
  <div className="flex items-center space-x-2 mb-4">
    <span className="text-gray-400 text-sm">Distance:</span>
    <div className="flex bg-gray-800 rounded-lg p-1">
      <button
        onClick={() => onUnitChange("mi")}
        className={`px-3 py-1 rounded text-sm transition-all ${
          unit === "mi"
            ? "bg-blue-500 text-white shadow-lg"
            : "text-gray-400 hover:text-white"
        }`}
      >
        Miles
      </button>
      <button
        onClick={() => onUnitChange("km")}
        className={`px-3 py-1 rounded text-sm transition-all ${
          unit === "km"
            ? "bg-blue-500 text-white shadow-lg"
            : "text-gray-400 hover:text-white"
        }`}
      >
        Kilometers
      </button>
    </div>
  </div>
);

// Car Image Component with realistic car photos
const CarImageModel = ({ make, model, isSelected }) => {
  const getCarImage = () => {
    const key = `${make}_${model}`.toLowerCase().replace(/\s+/g, "_");

    const carImages = {
      bmw_ix:
        "https://ucarecdn.com/1320a69b-f2c1-4968-90aa-40736e0d46ae/-/format/auto/",
      // We'll use the BMW iX as default for now and add more images later
      tesla_model_s:
        "https://ucarecdn.com/1320a69b-f2c1-4968-90aa-40736e0d46ae/-/format/auto/",
      tesla_model_3:
        "https://ucarecdn.com/1320a69b-f2c1-4968-90aa-40736e0d46ae/-/format/auto/",
      tesla_model_x:
        "https://ucarecdn.com/1320a69b-f2c1-4968-90aa-40736e0d46ae/-/format/auto/",
      tesla_model_y:
        "https://ucarecdn.com/1320a69b-f2c1-4968-90aa-40736e0d46ae/-/format/auto/",
      ford_mustang_mach_e:
        "https://ucarecdn.com/1320a69b-f2c1-4968-90aa-40736e0d46ae/-/format/auto/",
      rivian_r1t:
        "https://ucarecdn.com/1320a69b-f2c1-4968-90aa-40736e0d46ae/-/format/auto/",
      mercedes_eqc:
        "https://ucarecdn.com/1320a69b-f2c1-4968-90aa-40736e0d46ae/-/format/auto/",
      audi_e_tron:
        "https://ucarecdn.com/1320a69b-f2c1-4968-90aa-40736e0d46ae/-/format/auto/",
      lucid_air:
        "https://ucarecdn.com/1320a69b-f2c1-4968-90aa-40736e0d46ae/-/format/auto/",
    };

    return carImages[key] || carImages.bmw_ix;
  };

  const carImageUrl = getCarImage();

  return (
    <div className="relative w-24 h-16 mx-auto">
      <motion.div
        className="relative w-full h-full"
        animate={{
          scale: isSelected ? [1, 1.05, 1] : 1,
        }}
        transition={{
          duration: 2,
          repeat: isSelected ? Infinity : 0,
          ease: "easeInOut",
        }}
      >
        {/* Car Image */}
        <img
          src={carImageUrl}
          alt={`${make} ${model}`}
          className={`w-full h-full object-contain transition-all duration-500 ${
            isSelected
              ? "filter drop-shadow-2xl brightness-110"
              : "filter drop-shadow-lg brightness-95"
          }`}
          style={{
            filter: isSelected
              ? "drop-shadow(0 0 20px rgba(59, 130, 246, 0.6)) brightness(1.1)"
              : "drop-shadow(0 4px 12px rgba(0, 0, 0, 0.3)) brightness(0.95)",
          }}
        />

        {/* Brand badge overlay */}
        {make === "Tesla" && (
          <motion.div
            className="absolute -top-2 -right-2 w-6 h-6 bg-red-600 rounded-full flex items-center justify-center text-xs font-bold shadow-lg border-2 border-white"
            animate={{
              scale: isSelected ? [1, 1.1, 1] : 1,
              y: isSelected ? [0, -1, 0] : 0,
            }}
            transition={{
              duration: 3,
              repeat: isSelected ? Infinity : 0,
            }}
          >
            <span className="text-white text-xs font-bold">T</span>
          </motion.div>
        )}

        {make === "BMW" && (
          <motion.div
            className="absolute -top-2 -right-2 w-6 h-6 bg-blue-600 rounded-full flex items-center justify-center text-xs font-bold shadow-lg border-2 border-white"
            animate={{
              scale: isSelected ? [1, 1.1, 1] : 1,
            }}
            transition={{
              duration: 3,
              repeat: isSelected ? Infinity : 0,
            }}
          >
            <span className="text-white text-xs font-bold">BMW</span>
          </motion.div>
        )}
      </motion.div>

      {/* Electric charging indicator */}
      <motion.div
        className="absolute -top-1 -left-1 w-6 h-6 bg-gradient-to-r from-green-400 to-emerald-500 rounded-full flex items-center justify-center shadow-xl border-2 border-green-200"
        animate={{
          scale: isSelected ? [1, 1.2, 1] : [1, 1.1, 1],
          boxShadow: isSelected
            ? [
                "0 0 0 0 rgba(16, 185, 129, 0.4)",
                "0 0 0 8px rgba(16, 185, 129, 0)",
                "0 0 0 0 rgba(16, 185, 129, 0.4)",
              ]
            : "0 0 8px rgba(16, 185, 129, 0.3)",
        }}
        transition={{
          duration: 2,
          repeat: Infinity,
          ease: "easeInOut",
        }}
      >
        <span className="text-sm text-white font-bold">⚡</span>
      </motion.div>

      {/* Floating energy particles for selected vehicle */}
      {isSelected && (
        <div className="absolute -inset-4">
          {[...Array(3)].map((_, i) => (
            <motion.div
              key={i}
              className="absolute w-2 h-2 rounded-full"
              style={{
                backgroundColor:
                  i === 0 ? "#60a5fa" : i === 1 ? "#34d399" : "#f59e0b",
                left: `${30 + Math.random() * 40}%`,
                top: `${30 + Math.random() * 40}%`,
              }}
              animate={{
                y: [0, -15, 0],
                x: [0, Math.random() * 15 - 7.5, 0],
                opacity: [0, 1, 0],
                scale: [0, 1, 0],
              }}
              transition={{
                duration: 3,
                repeat: Infinity,
                delay: i * 1,
                ease: "easeInOut",
              }}
            />
          ))}
        </div>
      )}
    </div>
  );
};

// 3D Vehicle Card Component with realistic car images
export function Vehicle3DCard({
  vehicle,
  isSelected,
  onClick,
  unit = "mi",
  onUnitChange,
}) {
  // Convert miles to kilometers if needed
  const convertDistance = (miles) => {
    return unit === "km" ? Math.round(miles * 1.60934) : miles;
  };

  return (
    <div>
      {/* Unit selector - show only once at the top of vehicle list */}
      {onUnitChange && <UnitSelector unit={unit} onUnitChange={onUnitChange} />}

      <motion.button
        onClick={onClick}
        className={`w-full text-left p-5 rounded-xl border-2 transition-all duration-500 relative overflow-hidden group ${
          isSelected
            ? "border-blue-400 bg-gradient-to-br from-blue-900/60 via-blue-800/40 to-purple-900/40 shadow-2xl shadow-blue-500/50"
            : "border-gray-600 bg-gradient-to-br from-gray-800/90 to-gray-900/70 hover:border-gray-400 hover:shadow-xl hover:shadow-black/40"
        }`}
        whileHover={{
          scale: 1.02,
          y: -2,
        }}
        whileTap={{ scale: 0.98 }}
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4 }}
      >
        {/* Animated background glow */}
        {isSelected && (
          <motion.div
            className="absolute inset-0 bg-gradient-to-r from-blue-500/20 via-purple-500/15 to-blue-500/20 rounded-xl"
            animate={{
              backgroundPosition: ["0% 50%", "100% 50%", "0% 50%"],
            }}
            transition={{
              duration: 6,
              repeat: Infinity,
              ease: "linear",
            }}
            style={{
              backgroundSize: "200% 200%",
            }}
          />
        )}

        <div className="relative z-10 flex items-center justify-between">
          <div className="flex-1">
            <div className="font-bold text-lg mb-2 text-white group-hover:text-blue-300 transition-colors">
              {vehicle.make}{" "}
              <span className="text-gray-300 font-medium">{vehicle.model}</span>
            </div>

            <div className="space-y-2">
              <div className="grid grid-cols-2 gap-3">
                <div className="flex items-center space-x-2">
                  <motion.div
                    className="w-2 h-2 rounded-full bg-green-400 shadow-lg shadow-green-400/50"
                    animate={{ scale: isSelected ? [1, 1.4, 1] : 1 }}
                    transition={{ duration: 2, repeat: Infinity }}
                  />
                  <span className="text-sm font-medium text-gray-200">
                    {convertDistance(vehicle.range_miles)} {unit}
                  </span>
                </div>
                <div className="flex items-center space-x-2">
                  <motion.div
                    className="w-2 h-2 rounded-full bg-blue-400 shadow-lg shadow-blue-400/50"
                    animate={{ scale: isSelected ? [1, 1.4, 1] : 1 }}
                    transition={{ duration: 2, repeat: Infinity, delay: 0.7 }}
                  />
                  <span className="text-sm font-medium text-gray-200">
                    {vehicle.battery_capacity_kwh} kWh
                  </span>
                </div>
              </div>

              <div className="flex items-center space-x-2">
                <motion.div
                  className="w-2 h-2 rounded-full bg-yellow-400 shadow-lg shadow-yellow-400/50"
                  animate={{ scale: isSelected ? [1, 1.4, 1] : 1 }}
                  transition={{ duration: 2, repeat: Infinity, delay: 1.4 }}
                />
                <span className="text-xs text-gray-400 font-medium">
                  {vehicle.efficiency_kwh_per_mile} kWh/
                  {unit === "km" ? "km" : "mi"} • {vehicle.charging_speed_kw}kW
                </span>
              </div>
            </div>
          </div>

          <div className="ml-8 relative">
            <CarImageModel
              make={vehicle.make}
              model={vehicle.model}
              isSelected={isSelected}
            />
          </div>
        </div>

        {/* Bottom accent bar */}
        <motion.div
          className="absolute bottom-0 left-0 h-1 bg-gradient-to-r from-blue-400 via-purple-500 to-blue-400 rounded-b-xl"
          initial={{ width: "0%" }}
          animate={{
            width: isSelected ? "100%" : "0%",
          }}
          transition={{ duration: 0.8, ease: "easeInOut" }}
        />

        {/* Premium badge for luxury vehicles */}
        {(vehicle.make === "Tesla" ||
          vehicle.make === "Mercedes" ||
          vehicle.make === "Lucid") && (
          <motion.div
            className="absolute top-2 right-2 bg-gradient-to-r from-amber-400 to-yellow-500 text-black text-xs px-2 py-1 rounded-full font-bold shadow-lg"
            initial={{ scale: 0, rotate: -15 }}
            animate={{ scale: 1, rotate: 0 }}
            whileHover={{ scale: 1.1, rotate: 5 }}
            transition={{ delay: 0.2, type: "spring", stiffness: 200 }}
          >
            ✨ PREMIUM
          </motion.div>
        )}
      </motion.button>
    </div>
  );
}

export default Vehicle3DCard;
