"use client";
import React, { useState } from "react";
import { useApiData } from "../hooks/useApiData";
import { TeslaDashboard } from "./components/TeslaDashboard";

export default function HomePage() {
  const [activeTab, setActiveTab] = useState("driver");
  const { vehicles, stations, analytics } = useApiData(activeTab);

  return (
    <div className="min-h-screen bg-black text-white overflow-hidden">
      <TeslaDashboard
        vehicles={vehicles}
        stations={stations}
        analytics={analytics}
        activeTab={activeTab}
        setActiveTab={setActiveTab}
      />
    </div>
  );
}
