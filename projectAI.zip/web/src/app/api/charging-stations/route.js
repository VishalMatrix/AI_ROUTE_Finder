import sql from "@/app/api/utils/sql";

export async function GET(request) {
  try {
    const { searchParams } = new URL(request.url);
    const lat = searchParams.get('lat');
    const lng = searchParams.get('lng');
    const radius = searchParams.get('radius') || 50; // default 50 miles
    
    let stations;
    
    if (lat && lng) {
      // Find stations within radius using Haversine formula approximation
      stations = await sql`
        SELECT 
          id, name, address, latitude, longitude, provider, 
          total_ports, available_ports, charging_speed_kw, cost_per_kwh, status,
          (3959 * acos(cos(radians(${lat})) * cos(radians(latitude)) * 
           cos(radians(longitude) - radians(${lng})) + 
           sin(radians(${lat})) * sin(radians(latitude)))) AS distance_miles
        FROM charging_stations
        WHERE status = 'active'
        HAVING distance_miles <= ${radius}
        ORDER BY distance_miles
        LIMIT 50
      `;
    } else {
      // Return all active stations
      stations = await sql`
        SELECT id, name, address, latitude, longitude, provider, 
               total_ports, available_ports, charging_speed_kw, cost_per_kwh, status
        FROM charging_stations
        WHERE status = 'active'
        ORDER BY name
        LIMIT 100
      `;
    }
    
    return Response.json({ stations });
  } catch (error) {
    console.error('Error fetching charging stations:', error);
    return Response.json({ error: 'Failed to fetch charging stations' }, { status: 500 });
  }
}

export async function POST(request) {
  try {
    const { 
      name, address, latitude, longitude, provider, 
      total_ports, charging_speed_kw, cost_per_kwh 
    } = await request.json();
    
    if (!name || !address || !latitude || !longitude || !charging_speed_kw) {
      return Response.json({ error: 'Missing required fields' }, { status: 400 });
    }
    
    const result = await sql`
      INSERT INTO charging_stations 
      (name, address, latitude, longitude, provider, total_ports, available_ports, charging_speed_kw, cost_per_kwh)
      VALUES (${name}, ${address}, ${latitude}, ${longitude}, ${provider}, 
              ${total_ports || 1}, ${total_ports || 1}, ${charging_speed_kw}, ${cost_per_kwh})
      RETURNING *
    `;
    
    return Response.json({ station: result[0] });
  } catch (error) {
    console.error('Error creating charging station:', error);
    return Response.json({ error: 'Failed to create charging station' }, { status: 500 });
  }
}