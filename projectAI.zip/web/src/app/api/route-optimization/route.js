import sql from "@/app/api/utils/sql";

export async function POST(request) {
  try {
    const {
      startLat,
      startLng,
      endLat,
      endLng,
      vehicleModelId,
      batteryPercent,
      drivingStyle = "normal",
      minBatteryThreshold = 20, // New parameter for minimum battery threshold
    } = await request.json();

    if (
      !startLat ||
      !startLng ||
      !endLat ||
      !endLng ||
      !vehicleModelId ||
      batteryPercent === undefined
    ) {
      return Response.json(
        { error: "Missing required route parameters" },
        { status: 400 },
      );
    }

    // Get vehicle specifications
    const vehicleResult = await sql`
      SELECT * FROM vehicle_models WHERE id = ${vehicleModelId}
    `;

    if (vehicleResult.length === 0) {
      return Response.json(
        { error: "Vehicle model not found" },
        { status: 404 },
      );
    }

    const vehicle = vehicleResult[0];

    // Calculate straight-line distance (approximation)
    const distance = calculateDistance(startLat, startLng, endLat, endLng);

    // Apply driving style multiplier to efficiency
    const styleMultipliers = {
      eco: 0.85, // 15% more efficient
      normal: 1.0, // baseline
      aggressive: 1.25, // 25% less efficient
    };

    const efficiencyMultiplier = styleMultipliers[drivingStyle] || 1.0;
    const adjustedEfficiency =
      vehicle.efficiency_kwh_per_mile * efficiencyMultiplier;

    // Calculate energy consumption with 10% buffer for real-world conditions
    const energyConsumption = distance * adjustedEfficiency * 1.1;

    // Calculate current available energy
    const currentEnergyKwh =
      (batteryPercent / 100) * vehicle.battery_capacity_kwh;

    // Calculate energy at threshold
    const thresholdEnergyKwh =
      (minBatteryThreshold / 100) * vehicle.battery_capacity_kwh;

    // Calculate usable energy (current - threshold)
    const usableEnergyKwh = currentEnergyKwh - thresholdEnergyKwh;

    // Determine if charging is needed based on threshold
    const needsCharging = usableEnergyKwh < energyConsumption;
    let chargingStops = [];

    if (needsCharging) {
      // Find charging stations along the route
      const midLat = (startLat + endLat) / 2;
      const midLng = (startLng + endLng) / 2;

      const nearbyStations = await sql`
        SELECT 
          id, name, address, latitude, longitude, provider,
          charging_speed_kw, cost_per_kwh, available_ports,
          (3959 * acos(cos(radians(${midLat})) * cos(radians(latitude)) * 
           cos(radians(longitude) - radians(${midLng})) + 
           sin(radians(${midLat})) * sin(radians(latitude)))) AS distance_miles
        FROM charging_stations
        WHERE status = 'active' AND available_ports > 0
        HAVING distance_miles <= 25
        ORDER BY distance_miles, charging_speed_kw DESC
        LIMIT 10
      `;

      // Select best charging station (closest with fastest charging)
      if (nearbyStations.length > 0) {
        const bestStation = nearbyStations[0];

        // Calculate charging needed to complete trip with comfortable margin
        const energyNeeded =
          energyConsumption -
          usableEnergyKwh +
          vehicle.battery_capacity_kwh * 0.1; // 10% additional buffer

        // Ensure we don't exceed battery capacity
        const maxEnergyToAdd = vehicle.battery_capacity_kwh - currentEnergyKwh;
        const actualEnergyToAdd = Math.min(energyNeeded, maxEnergyToAdd);

        const chargingTimeHours =
          actualEnergyToAdd /
          Math.min(bestStation.charging_speed_kw, vehicle.charging_speed_kw);
        const chargingTimeMinutes = Math.ceil(chargingTimeHours * 60);

        chargingStops.push({
          station: bestStation,
          energyToAdd: actualEnergyToAdd,
          chargingTimeMinutes,
          cost: actualEnergyToAdd * (bestStation.cost_per_kwh || 0.3),
          reason: `Battery would drop below ${minBatteryThreshold}% threshold`,
        });
      }
    }

    // Estimate travel time (assuming average 60 mph + charging time)
    const drivingTimeMinutes = Math.ceil((distance / 60) * 60);
    const chargingTimeMinutes = chargingStops.reduce(
      (total, stop) => total + stop.chargingTimeMinutes,
      0,
    );
    const totalTravelTime = drivingTimeMinutes + chargingTimeMinutes;

    // Calculate final battery percentage at destination
    const totalEnergyAdded = chargingStops.reduce(
      (total, stop) => total + stop.energyToAdd,
      0,
    );
    const finalBatteryKwh =
      currentEnergyKwh + totalEnergyAdded - energyConsumption;
    const batteryAtDestination = Math.round(
      (finalBatteryKwh / vehicle.battery_capacity_kwh) * 100,
    );

    // Save route calculation
    const routeResult = await sql`
      INSERT INTO route_calculations 
      (start_latitude, start_longitude, end_latitude, end_longitude, 
       vehicle_model_id, starting_battery_percent, total_distance_miles, 
       estimated_energy_consumption_kwh, total_travel_time_minutes)
      VALUES (${startLat}, ${startLng}, ${endLat}, ${endLng}, 
              ${vehicleModelId}, ${batteryPercent}, ${distance}, 
              ${energyConsumption}, ${totalTravelTime})
      RETURNING id
    `;

    const optimizedRoute = {
      routeId: routeResult[0].id,
      distance: Math.round(distance * 10) / 10,
      energyConsumption: Math.round(energyConsumption * 100) / 100,
      drivingTimeMinutes,
      chargingTimeMinutes,
      totalTravelTime,
      chargingStops,
      batteryAtDestination: Math.max(0, batteryAtDestination), // Ensure non-negative
      usableRange: Math.round((usableEnergyKwh / adjustedEfficiency) * 10) / 10,
      thresholdUsed: minBatteryThreshold,
      recommendations: generateRecommendations(
        needsCharging,
        chargingStops,
        drivingStyle,
        minBatteryThreshold,
        batteryAtDestination,
      ),
    };

    return Response.json({ route: optimizedRoute });
  } catch (error) {
    console.error("Error calculating route:", error);
    return Response.json(
      { error: "Failed to calculate optimal route" },
      { status: 500 },
    );
  }
}

// Helper function to calculate distance between two points (Haversine formula)
function calculateDistance(lat1, lon1, lat2, lon2) {
  const R = 3959; // Earth's radius in miles
  const dLat = toRadians(lat2 - lat1);
  const dLon = toRadians(lon2 - lon1);
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(toRadians(lat1)) *
      Math.cos(toRadians(lat2)) *
      Math.sin(dLon / 2) *
      Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return R * c;
}

function toRadians(degrees) {
  return degrees * (Math.PI / 180);
}

function generateRecommendations(
  needsCharging,
  chargingStops,
  drivingStyle,
  minBatteryThreshold,
  batteryAtDestination,
) {
  const recommendations = [];

  if (needsCharging && chargingStops.length === 0) {
    recommendations.push({
      type: "warning",
      message:
        "No charging stations found along your route. Consider starting with more battery or finding alternative stations.",
    });
  }

  if (drivingStyle === "aggressive") {
    recommendations.push({
      type: "tip",
      message:
        "Switch to Eco mode to improve efficiency and extend your range by up to 15%.",
    });
  }

  if (chargingStops.length > 0) {
    recommendations.push({
      type: "info",
      message: `Plan for a ${chargingStops[0].chargingTimeMinutes}-minute charging stop. Consider grabbing a meal or coffee.`,
    });
  }

  return recommendations;
}
