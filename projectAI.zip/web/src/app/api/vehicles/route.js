import sql from "@/app/api/utils/sql";

export async function GET() {
  try {
    const vehicles = await sql`
      SELECT id, make, model, battery_capacity_kwh, range_miles, efficiency_kwh_per_mile, charging_speed_kw
      FROM vehicle_models
      ORDER BY make, model
    `;
    
    return Response.json({ vehicles });
  } catch (error) {
    console.error('Error fetching vehicles:', error);
    return Response.json({ error: 'Failed to fetch vehicles' }, { status: 500 });
  }
}

export async function POST(request) {
  try {
    const { make, model, battery_capacity_kwh, range_miles, efficiency_kwh_per_mile, charging_speed_kw } = await request.json();
    
    if (!make || !model || !battery_capacity_kwh || !range_miles || !efficiency_kwh_per_mile || !charging_speed_kw) {
      return Response.json({ error: 'Missing required fields' }, { status: 400 });
    }
    
    const result = await sql`
      INSERT INTO vehicle_models (make, model, battery_capacity_kwh, range_miles, efficiency_kwh_per_mile, charging_speed_kw)
      VALUES (${make}, ${model}, ${battery_capacity_kwh}, ${range_miles}, ${efficiency_kwh_per_mile}, ${charging_speed_kw})
      RETURNING *
    `;
    
    return Response.json({ vehicle: result[0] });
  } catch (error) {
    console.error('Error creating vehicle:', error);
    return Response.json({ error: 'Failed to create vehicle' }, { status: 500 });
  }
}