import sql from "@/app/api/utils/sql";

export async function GET(request) {
  try {
    const { searchParams } = new URL(request.url);
    const latParam = searchParams.get("lat");
    const lngParam = searchParams.get("lng");
    const radiusParam = searchParams.get("radius") || "10";

    // Parse and validate coordinates
    const lat = latParam ? parseFloat(latParam) : 37.7749; // Default to San Francisco
    const lng = lngParam ? parseFloat(lngParam) : -122.4194;
    const radius = parseInt(radiusParam) || 10;

    // Validate coordinates are valid numbers
    if (
      isNaN(lat) ||
      isNaN(lng) ||
      lat < -90 ||
      lat > 90 ||
      lng < -180 ||
      lng > 180
    ) {
      return Response.json(
        { error: "Invalid coordinates provided" },
        { status: 400 },
      );
    }

    if (isNaN(radius) || radius < 1 || radius > 100) {
      return Response.json(
        { error: "Radius must be between 1 and 100 miles" },
        { status: 400 },
      );
    }

    // Get demand analytics for the area
    const demandData = await sql`
      SELECT 
        location_latitude, location_longitude, radius_miles,
        daily_traffic_count, average_dwell_time_minutes,
        grid_capacity_kw, recommendation_score,
        (3959 * acos(cos(radians(${lat})) * cos(radians(location_latitude)) * 
         cos(radians(location_longitude) - radians(${lng})) + 
         sin(radians(${lat})) * sin(radians(location_latitude)))) AS distance_miles
      FROM demand_analytics
      HAVING distance_miles <= ${radius}
      ORDER BY recommendation_score DESC, distance_miles
      LIMIT 20
    `;

    // Get existing charging stations in the area
    const existingStations = await sql`
      SELECT 
        id, name, latitude, longitude, provider, total_ports, charging_speed_kw,
        (3959 * acos(cos(radians(${lat})) * cos(radians(latitude)) * 
         cos(radians(longitude) - radians(${lng})) + 
         sin(radians(${lat})) * sin(radians(latitude)))) AS distance_miles
      FROM charging_stations
      WHERE status = 'active'
      HAVING distance_miles <= ${radius}
      ORDER BY distance_miles
    `;

    // Ensure we have some data to work with
    if (demandData.length === 0 && existingStations.length === 0) {
      // Create some default data for the area if none exists
      const defaultAnalytics = {
        marketOverview: {
          totalExistingStations: 0,
          totalExistingPorts: 0,
          averageDailyTraffic: 5000,
          marketSaturation: "Low",
          saturationRatio: 0.01,
        },
        siteRecommendations: [
          {
            latitude: lat,
            longitude: lng,
            score: 75,
            dailyTraffic: 5000,
            competition: 0,
            estimatedROI: 18.5,
            recommendedPorts: 8,
            gridCapacity: 400,
            dwellTime: 35,
          },
        ],
        roiProjections: {
          installationCost: 150000,
          annualRevenue: 127750,
          annualProfit: 112750,
          paybackPeriodYears: 1.3,
          fiveYearROI: 275,
          utilizationRate: 35,
        },
        competitorAnalysis: {
          topProviders: [
            { provider: "Tesla", stationCount: 0 },
            { provider: "Electrify America", stationCount: 0 },
          ],
          speedDistribution: { fast: 0, medium: 0, slow: 0 },
          marketLeader: "None",
          averagePortsPerStation: 8,
        },
        demandPatterns: {
          totalDailyTraffic: 5000,
          averageDwellTime: 35,
          peakHours: ["8:00-10:00 AM", "5:00-7:00 PM"],
          seasonalTrends: "Summer: +15%, Winter: -10%",
          growthProjection: "+25% annually",
        },
      };

      return Response.json({ analytics: defaultAnalytics });
    }

    // Calculate market saturation
    const totalPorts = existingStations.reduce(
      (sum, station) => sum + (station.total_ports || 0),
      0,
    );
    const averageDailyTraffic =
      demandData.length > 0
        ? demandData.reduce(
            (sum, data) => sum + (data.daily_traffic_count || 0),
            0,
          ) / demandData.length
        : 5000;
    const saturationRatio = totalPorts / (averageDailyTraffic / 1000); // ports per 1000 daily vehicles

    // Generate site recommendations
    const siteRecommendations = generateSiteRecommendations(
      demandData,
      existingStations,
      saturationRatio,
    );

    // Calculate ROI projections
    const roiProjections = calculateROIProjections(
      demandData,
      existingStations,
    );

    const analytics = {
      marketOverview: {
        totalExistingStations: existingStations.length,
        totalExistingPorts: totalPorts,
        averageDailyTraffic: Math.round(averageDailyTraffic),
        marketSaturation:
          saturationRatio > 0.1
            ? "High"
            : saturationRatio > 0.05
              ? "Medium"
              : "Low",
        saturationRatio: Math.round(saturationRatio * 1000) / 1000,
      },
      siteRecommendations,
      roiProjections,
      competitorAnalysis: analyzeCompetition(existingStations),
      demandPatterns: analyzeDemandPatterns(demandData),
    };

    return Response.json({ analytics });
  } catch (error) {
    console.error("Error fetching business analytics:", error);
    return Response.json(
      {
        error: "Failed to fetch business analytics",
        details: error.message,
      },
      { status: 500 },
    );
  }
}

export async function POST(request) {
  try {
    const {
      latitude,
      longitude,
      radius,
      dailyTrafficCount,
      averageDwellTime,
      gridCapacity,
      recommendationScore,
    } = await request.json();

    if (!latitude || !longitude || !radius) {
      return Response.json(
        { error: "Missing required location data" },
        { status: 400 },
      );
    }

    const result = await sql`
      INSERT INTO demand_analytics 
      (location_latitude, location_longitude, radius_miles, daily_traffic_count, 
       average_dwell_time_minutes, grid_capacity_kw, recommendation_score)
      VALUES (${latitude}, ${longitude}, ${radius}, ${dailyTrafficCount}, 
              ${averageDwellTime}, ${gridCapacity}, ${recommendationScore})
      RETURNING *
    `;

    return Response.json({ analytics: result[0] });
  } catch (error) {
    console.error("Error creating analytics data:", error);
    return Response.json(
      { error: "Failed to create analytics data" },
      { status: 500 },
    );
  }
}

function generateSiteRecommendations(
  demandData,
  existingStations,
  saturationRatio,
) {
  const recommendations = [];

  // High-demand, low-competition areas
  demandData.forEach((data) => {
    const nearbyStations = existingStations.filter((station) => {
      const distance = calculateDistance(
        data.location_latitude,
        data.location_longitude,
        station.latitude,
        station.longitude,
      );
      return distance <= 2; // within 2 miles
    });

    const competitionScore = Math.max(0, 100 - nearbyStations.length * 20);
    const demandScore = Math.min(100, (data.daily_traffic_count || 0) / 100);
    const overallScore =
      (competitionScore + demandScore + (data.recommendation_score || 50)) / 3;

    if (overallScore >= 60) {
      recommendations.push({
        latitude: data.location_latitude,
        longitude: data.location_longitude,
        score: Math.round(overallScore),
        dailyTraffic: data.daily_traffic_count || 0,
        competition: nearbyStations.length,
        estimatedROI: calculateEstimatedROI(data, nearbyStations.length),
        recommendedPorts: Math.ceil((data.daily_traffic_count || 1000) / 500), // 1 port per 500 daily vehicles
        gridCapacity: data.grid_capacity_kw || 0,
        dwellTime: data.average_dwell_time_minutes || 30,
      });
    }
  });

  return recommendations.sort((a, b) => b.score - a.score).slice(0, 10);
}

function calculateROIProjections(demandData, existingStations) {
  const avgDailyTraffic =
    demandData.reduce((sum, data) => sum + (data.daily_traffic_count || 0), 0) /
    Math.max(demandData.length, 1);
  const avgUtilization = Math.min(0.7, avgDailyTraffic / 10000); // max 70% utilization

  // Assumptions for ROI calculation
  const installationCost = 150000; // $150k per station
  const maintenanceCostPerYear = 15000; // $15k per year
  const revenuePerKwh = 0.35; // $0.35 per kWh
  const avgSessionKwh = 25; // 25 kWh per session
  const sessionsPerDay = avgUtilization * 50; // up to 50 sessions per day at full utilization

  const annualRevenue = sessionsPerDay * 365 * avgSessionKwh * revenuePerKwh;
  const annualProfit = annualRevenue - maintenanceCostPerYear;
  const paybackPeriod = installationCost / annualProfit;

  return {
    installationCost,
    annualRevenue: Math.round(annualRevenue),
    annualProfit: Math.round(annualProfit),
    paybackPeriodYears: Math.round(paybackPeriod * 10) / 10,
    fiveYearROI: Math.round(
      ((annualProfit * 5 - installationCost) / installationCost) * 100,
    ),
    utilizationRate: Math.round(avgUtilization * 100),
  };
}

function analyzeCompetition(existingStations) {
  const providerCounts = {};
  const speedDistribution = { fast: 0, medium: 0, slow: 0 };

  existingStations.forEach((station) => {
    // Count by provider
    providerCounts[station.provider] =
      (providerCounts[station.provider] || 0) + 1;

    // Categorize by charging speed
    if (station.charging_speed_kw >= 150) {
      speedDistribution.fast++;
    } else if (station.charging_speed_kw >= 50) {
      speedDistribution.medium++;
    } else {
      speedDistribution.slow++;
    }
  });

  const topProviders = Object.entries(providerCounts)
    .sort(([, a], [, b]) => b - a)
    .slice(0, 5)
    .map(([provider, count]) => ({ provider, stationCount: count }));

  return {
    topProviders,
    speedDistribution,
    marketLeader: topProviders[0]?.provider || "None",
    averagePortsPerStation: Math.round(
      existingStations.reduce((sum, s) => sum + s.total_ports, 0) /
        Math.max(existingStations.length, 1),
    ),
  };
}

function analyzeDemandPatterns(demandData) {
  const totalTraffic = demandData.reduce(
    (sum, data) => sum + (data.daily_traffic_count || 0),
    0,
  );
  const avgDwellTime =
    demandData.reduce(
      (sum, data) => sum + (data.average_dwell_time_minutes || 0),
      0,
    ) / Math.max(demandData.length, 1);

  return {
    totalDailyTraffic: totalTraffic,
    averageDwellTime: Math.round(avgDwellTime),
    peakHours: ["8:00-10:00 AM", "5:00-7:00 PM"], // simplified
    seasonalTrends: "Summer: +15%, Winter: -10%", // simplified
    growthProjection: "+25% annually", // simplified
  };
}

function calculateEstimatedROI(demandData, competitionCount) {
  const baseROI = 15; // 15% base ROI
  const demandMultiplier = Math.min(
    2,
    (demandData.daily_traffic_count || 1000) / 5000,
  );
  const competitionPenalty = competitionCount * 3; // 3% penalty per competitor

  return Math.max(
    5,
    Math.round((baseROI * demandMultiplier - competitionPenalty) * 10) / 10,
  );
}

function calculateDistance(lat1, lon1, lat2, lon2) {
  const R = 3959; // Earth's radius in miles
  const dLat = toRadians(lat2 - lat1);
  const dLon = toRadians(lon2 - lon1);
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(toRadians(lat1)) *
      Math.cos(toRadians(lat2)) *
      Math.sin(dLon / 2) *
      Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return R * c;
}

function toRadians(degrees) {
  return degrees * (Math.PI / 180);
}
